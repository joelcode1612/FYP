"""Local, network-free objective proposer for governed simulation.

Why a dedicated simulator
-------------------------
The entrepreneur's confirmed M2 declarations are real personal data. The
existing ``SyntheticBdjDisclosure`` authorizes exactly one *synthetic* packet to
the approved third-party provider, and the real-data authorisation row is bound
to a specific source fingerprint / ruleset / prompt. Neither is an
authorisation to disclose this source to a cloud model, and this checkpoint is
explicitly forbidden from widening that policy to obtain a green test.

So execution here is **simulated locally**:

* the provider never opens a socket (no ``httpx`` import, no credential),
* the disclosure gate refuses every stage/model/packet except the exact
  simulator composition built for this one execution,
* the output still has to pass ``validate_objective_proposal`` and
  ``bind_to_business_context`` unchanged, and is persisted with
  ``execution_mode='SIMULATED'`` and ``model_provider='simulated-objective-v1'``
  so no later reader can mistake it for a model call.

The proposal text is derived mechanically from the confirmed declarations: a
recommendation may only cite an answer whose confirmed value is itself an
uncertainty literal. Nothing is invented, and a source with no uncertainty
literal produces the bounded exploratory recommendation instead.
"""
from __future__ import annotations

from sitewise.project1.contracts import WorkflowHeld
from sitewise.project1.objective_proposal import (
    CONTRACT_VERSION, DEFAULT_SUPPORTING_LITERALS, MAX_RECOMMENDATIONS,
    PROBLEM_TYPE_FOR_STATUS, SUPPORTING_LITERALS,
)
from sitewise.project1.provider import ENDPOINT

SIMULATOR_MODEL = "simulated-objective-v1"
SIMULATOR_ENDPOINT = "local://simulated-objective"
SIMULATOR_MODE = "json_schema"
PROJECTION_SCHEMA = "project1-m2-projection/1-candidate"


class ObjectiveSimulationDisclosure:
    """Fail-closed gate for the simulator composition.

    Mirrors the ``ModelRunner`` disclosure port signature so the governed runner
    can be composed unchanged. It grants nothing about third-party disclosure:
    it only asserts that this execution is the simulator, bound to this exact
    source revision and persisted context.
    """

    def __init__(self, *, assessment_id, revision, confirmation_id,
                 source_fingerprint, context_packet_hash):
        self.assessment_id = str(assessment_id)
        self.revision = int(revision)
        self.confirmation_id = str(confirmation_id)
        self.source_fingerprint = str(source_fingerprint)
        self.context_packet_hash = str(context_packet_hash)

    def require_current(self, stage, packet, endpoint, model):
        if stage != "BDJ":
            raise WorkflowHeld("DISCLOSURE_STAGE_NOT_AUTHORIZED")
        if model != SIMULATOR_MODEL:
            # A configured cloud model must never inherit this authorisation.
            raise WorkflowHeld("DISCLOSURE_MODEL_MISMATCH")
        if endpoint not in {SIMULATOR_ENDPOINT, ENDPOINT}:
            raise WorkflowHeld("DISCLOSURE_ENDPOINT_MISMATCH")
        if not isinstance(packet, dict) or packet.get("schema_version") != PROJECTION_SCHEMA:
            raise WorkflowHeld("DISCLOSURE_SOURCE_CLASS_INVALID")
        if packet.get("source_fingerprint") != self.source_fingerprint:
            raise WorkflowHeld("DISCLOSURE_SOURCE_MISMATCH")
        confirmation = packet.get("confirmation") or {}
        if (str(packet.get("assessment_id")) != self.assessment_id
                or packet.get("assessment_revision") != self.revision
                or str(confirmation.get("confirmation_id")) != self.confirmation_id):
            raise WorkflowHeld("DISCLOSURE_ASSESSMENT_BINDING_MISMATCH")


def _values(value):
    return value if isinstance(value, list) else [value]


def _supporting_literals(item_key):
    return SUPPORTING_LITERALS.get(item_key, DEFAULT_SUPPORTING_LITERALS)


def simulate_objective_proposal(packet: dict) -> dict:
    """Deterministic ``bdj-objective-proposal/1`` payload from confirmed answers.

    One MOST_SUGGESTED per confirmed uncertainty literal, capped by the
    contract. When no confirmed answer carries a literal, the result is the
    single bounded exploratory SUGGESTED — never a fabricated gap.
    """
    declarations = [d for d in packet.get("declarations", []) if isinstance(d, dict)]
    recommendations = []
    for row in sorted(declarations, key=lambda r: str(r.get("item_key"))):
        if row.get("answer_state") != "ANSWERED":
            continue
        allowed = _supporting_literals(str(row.get("item_key")))
        literal = next((v for v in _values(row.get("value"))
                        if isinstance(v, str) and v in allowed), None)
        if literal is None:
            continue
        item_key = str(row["item_key"])
        recommendations.append({
            "recommendation_status": "MOST_SUGGESTED",
            "problem_type": PROBLEM_TYPE_FOR_STATUS["MOST_SUGGESTED"],
            "problem": (f"The confirmed answer to {item_key} is {literal}, so this "
                        "element of the business concept remains undecided."),
            "research_objective": (f"To investigate what the confirmed {item_key} "
                                   "declaration leaves unresolved for the proposed concept."),
            "source_refs": [{
                "item_key": item_key,
                "answer_revision_id": str(row["answer_revision_id"]),
                "item_version_id": str(row["item_version_id"]),
            }],
            "reason": ("The cited declaration records an explicit uncertainty literal; "
                       "no further evidence is inferred from it."),
            "authority": "CANDIDATE_ONLY",
        })
        if len(recommendations) >= MAX_RECOMMENDATIONS:
            break

    if not recommendations:
        recommendations.append({
            "recommendation_status": "SUGGESTED",
            "problem_type": PROBLEM_TYPE_FOR_STATUS["SUGGESTED"],
            "problem": None,
            "research_objective": ("To explore the factors that influence customers' "
                                   "selection of the proposed cafe concept."),
            "source_refs": [],
            "reason": ("No confirmed M2 answer establishes an existing problem; this "
                       "objective is exploratory and not source-backed."),
            "authority": "CANDIDATE_ONLY",
        })

    return {"contract_version": CONTRACT_VERSION, "recommendations": recommendations}


class SimulatedObjectiveProvider:
    """In-process provider. ``complete`` performs no I/O and holds no secret."""

    model = SIMULATOR_MODEL
    mode = SIMULATOR_MODE

    def __init__(self, packet: dict):
        self.packet = packet
        self.last_identity = None
        self.last_execution = None

    def prepare_payload(self, messages, output_type):
        """Shape-compatible with TokenHarbor.prepare_payload; never dispatched."""
        return {"model": self.model, "messages": messages,
                "response_format": {"type": "json_schema",
                                    "json_schema": {"name": output_type.__name__,
                                                    "strict": True,
                                                    "schema": output_type.model_json_schema()}}}

    def complete(self, messages, output_type):
        output = simulate_objective_proposal(self.packet)
        # Validated locally so a contract drift fails here, not at persistence.
        output_type.model_validate(output)
        self.last_identity = {
            "requested_model": self.model, "returned_model": None,
            "classification": "SIMULATED_LOCAL", "identity_verified": False,
        }
        self.last_execution = {
            "model_requested": self.model, "model_returned": None,
            "identity_verified": False, "http_status": None, "usage": None,
            "schema_validation": "VALID", "dispatched": False,
            "dispatch_attempted": False, "execution_mode": "SIMULATED",
            "provider": "in_process_simulator",
        }
        return output
