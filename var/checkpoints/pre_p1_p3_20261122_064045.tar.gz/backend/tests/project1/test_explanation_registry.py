"""CP2: registry-backed deterministic fallbacks inside the single explanation module.

Three properties are load-bearing and each is tested directly:

1. **Single source of prose.** The registry file is the only place item prose
   lives. The hash pin makes an edit to that prose impossible to miss.
2. **Twelve evidence states.** Four instrument gates and eight data states, each
   reachable from EE-01 counts plus the item's contract status, none decidable
   from a caller-supplied boolean.
3. **Numerical fidelity.** A withheld render carries no figure. A substantive
   render copies supplied figures and computes nothing. The LLM path keeps the
   original strict guard, so the registry allowance cannot be borrowed by a model.
"""
from __future__ import annotations

import hashlib
import json
from uuid import uuid4

import pytest

from sitewise.domain.cq_runtime import CqRefused
from sitewise.project1.contracts import WorkflowHeld
from sitewise.project1.explanation_contracts import (
    SCHEMA_VERSION,
    ExplanationOutput,
    insufficient_evidence_output,
    question_evidence_output,
    validate_candidate,
)
from sitewise.project1.explanation_registry import (
    ALL_STATES,
    EVIDENCE_STATES,
    EXPECTED_REGISTRY_SHA256,
    INSTRUMENT_GATES,
    REGISTRY_PATH,
    decide_state,
    effective_state,
    fill_item_template,
    load_registry,
    render_question,
    resolve_question,
    state_sentence,
)
from sitewise.services.ee01_explanation_service import (
    QUESTION_TEMPLATE_PRODUCER,
    TEMPLATE_PRODUCER,
    Ee01ExplanationService,
)


# --------------------------------------------------------------------- helpers

@pytest.fixture(scope='module')
def registry():
    return load_registry()


def _entry(registry, question_id):
    entry = registry.question(question_id)
    assert entry is not None
    return entry


def _packet(registry, rendered, *, task_mode='CLAIM_EXPLANATION'):
    """Minimal packet that satisfies the validator's reference universe."""
    return {
        'task_mode': task_mode,
        'context_id': 'ctx-hash',
        'snapshot_id': 'snap-id',
        'reference_universe': list(rendered['missing_evidence_references']),
    }


class FakeEe01:
    """Snapshot stub with a resolvable slot and stored funnel counts."""

    def __init__(self, *, slot_id='Q05', q=40, s=38, a=36, v=30, refused=2,
                 invalid=4, excluded=0, findings=None, cells=None,
                 authority='AUTHORITY_UNVERIFIED'):
        self.assessment_id = uuid4()
        self.campaign_id = uuid4()
        self.snapshot_id = uuid4()
        self.slot_id = slot_id
        self.counts = {'ANSWERED_SUBSTANTIVE': v, 'ANSWERED_NON_SUBSTANTIVE': a - v,
                       'REFUSED': refused, 'INVALID': invalid, 'SKIPPED': s - a,
                       'SHOWN_NO_ANSWER': 0, 'not_shown': q - s, 'excluded': excluded}
        self.context = {
            'snapshot_id': str(self.snapshot_id), 'fingerprint': 'a' * 64,
            'assessment_id': str(self.assessment_id), 'campaign_id': str(self.campaign_id),
            'source_hash': 'b' * 64, 'rules_hash': 'c' * 64,
            'authority': authority, 'findings': findings or [],
            'gates': ['EXPLANATION_TEMPLATE_AUTHORITY_UNVERIFIED',
                      'A10_ADAPTER_UNVERIFIED', 'REPORT_ADMISSION_REQUIRED'],
        }
        from sitewise.domain.customer_questionnaire import digest
        self.context_hash = digest(self.context)
        self._counts = (q, s, a, v)
        self._cells = cells or []

    def report_readback(self, actor, aid, cid, sid):
        return {'status': 'REPORT_FINDINGS_WITHHELD_NO_AUTHORIZED_SOURCE',
                'context_hash': self.context_hash, 'context': dict(self.context),
                'findings': self.context['findings']}

    def read(self, actor, aid, cid, sid):
        q, s, a, v = self._counts
        return {'id': self.snapshot_id, 'assessment_id': self.assessment_id,
                'campaign_id': self.campaign_id, 'question_version': f'{self.slot_id}@1',
                'slot_id': self.slot_id,
                'fingerprint': 'a' * 64, 'scope': 'ISOLATED_TEST',
                'q': q, 's': s, 'a': a, 'v': v,
                'counts_json': json.dumps(self.counts),
                'metadata_json': {'instrument_version': 'SYN-1', 'bank_version': 'SYN-B',
                    'routing_version': 'SYN-P', 'consent_version': 'SYN-C',
                    'qualification_versions': ['SYN-Q'],
                    'privacy_policy': 'WITHHOLD_ALL_FINDINGS',
                    'rule': 'CUST03_CURRENT_ATTEMPT_DIAGNOSTIC',
                    'selection': 'LATEST_ATTEMPT', 'cutoff_basis': 'SNAPSHOT',
                    'scientific_gaps': ['A_DEFINITION_UNRESOLVED']},
                'cells': self._cells}


def _explain(fake, **kwargs):
    return Ee01ExplanationService(fake).explain(
        uuid4(), fake.assessment_id, fake.campaign_id, fake.snapshot_id,
        task_mode=kwargs.pop('task_mode', 'CLAIM_EXPLANATION'),
        claim_ids=kwargs.pop('claim_ids', []),
        context_hash=fake.context_hash, **kwargs)


# ------------------------------------------------------------------- registry

def test_registry_is_hash_pinned_and_current(registry):
    raw = REGISTRY_PATH.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED_REGISTRY_SHA256
    assert registry.sha256 == EXPECTED_REGISTRY_SHA256


def test_registry_covers_all_thirteen_items(registry):
    assert sorted(registry.questions) == [f'Q{n:02d}' for n in range(1, 14)]


def test_registry_carries_the_pinned_instrument(registry):
    assert registry.instrument_version == 'P3-01C-VNEXT-0.6.1-CUST-REC'
    assert registry.instrument_sha256 == (
        'ec2b5494ecf82447076e0d7a2bfb57599a24f049bbcc925a9ecbea6e833bce59')


def test_no_item_is_usable_for_substantive_report(registry):
    """The registry must not manufacture availability; it is derived from status."""
    usable = [q for q, e in registry.questions.items()
              if e.template_usable_for_substantive_report]
    assert usable == []


def test_every_item_has_three_templates(registry):
    for entry in registry.questions.values():
        assert entry.withheld.template_id == f'FB-{entry.question_id}-WITHHELD'
        assert entry.valid.template_id == f'VD-{entry.question_id}-APPROVED'
        assert entry.limitation.template_id == f'LM-{entry.question_id}-LIMIT'
        assert entry.withheld.text.strip()
        assert entry.valid.text.strip()
        assert entry.limitation.text.strip()


def test_twelve_states_are_declared(registry):
    assert len(INSTRUMENT_GATES) == 4
    assert len(EVIDENCE_STATES) == 8
    assert len(ALL_STATES) == 12
    for state in ALL_STATES:
        assert state in registry.state_templates
    assert registry.state_templates['VALID_APPROVED'] is None


def test_q10_valid_template_declares_the_per_feature_placeholders(registry):
    """Q10 needs a per-feature denominator EE-01 cannot supply — recorded, not hidden."""
    entry = _entry(registry, 'Q10')
    assert 'feature' in entry.valid.placeholders
    assert 'V_feature' in entry.valid.placeholders
    with pytest.raises(CqRefused) as exc:
        fill_item_template(entry.valid, {'count': 3})
    assert 'TEMPLATE_FIGURE_MISSING' in str(exc.value)


# ------------------------------------------------------------------ resolution

def test_explicit_question_id_resolves(registry):
    entry, basis = resolve_question(registry, question_id='Q05')
    assert entry.question_id == 'Q05'
    assert basis == 'EXPLICIT_QUESTION_ID'


def test_slot_id_resolution_is_labelled_as_derived(registry):
    entry, basis = resolve_question(registry, slot_id='Q06')
    assert entry.question_id == 'Q06'
    assert basis == 'DERIVED_FROM_SLOT_ID'


def test_per_feature_q10_slot_is_a_known_unsupported_shape(registry):
    entry, basis = resolve_question(registry, slot_id='Q10:F01')
    assert entry is None
    assert basis == 'PER_FEATURE_SLOT_UNSUPPORTED'


def test_unknown_slot_does_not_guess(registry):
    entry, basis = resolve_question(registry, slot_id='ZZZ')
    assert entry is None
    assert basis == 'UNRESOLVED'


def test_a_caller_cannot_bind_one_items_prose_to_another_items_snapshot():
    with pytest.raises(CqRefused) as exc:
        _explain(FakeEe01(slot_id='Q05'), question_id='Q06')
    assert 'EXPLANATION_QUESTION_BINDING_MISMATCH' in str(exc.value)


# ---------------------------------------------------------------- state machine

def test_all_twelve_states_are_reachable(registry):
    """Each state is produced by a distinct, decidable condition."""
    q05 = _entry(registry, 'Q05')          # MISSING_APPROVED_STIMULUS gate
    q03 = _entry(registry, 'Q03')          # BLOCKED_SOURCE gate
    q11 = _entry(registry, 'Q11')          # NOT_AUTHORIZED gate
    q06 = _entry(registry, 'Q06')          # MISSING_APPROVED_BANK gate
    q09 = _entry(registry, 'Q09')          # routing unresolved, gate BLOCKED_SOURCE
    q01 = _entry(registry, 'Q01')          # routing resolved

    seen = {}
    # -- instrument gates
    seen[decide_state(q11, q=40, s=40, a=40, v=30)[0]] = 'NOT_AUTHORIZED'
    seen[decide_state(q03, q=40, s=40, a=40, v=30)[0]] = 'BLOCKED_SOURCE'
    seen[decide_state(q05, q=40, s=40, a=40, v=30)[0]] = 'MISSING_APPROVED_STIMULUS'
    seen[decide_state(q06, q=40, s=40, a=40, v=30)[0]] = 'MISSING_APPROVED_BANK'
    # -- data states
    assert decide_state(q01, q=0, s=0, a=0, v=0, excluded=5, total_units=5)[1] == \
        'WITHDRAWN_OR_NO_CONSENT'
    assert decide_state(q01, q=0, s=0, a=0, v=0)[1] == 'NO_ADMISSIBLE_RESPONSES'
    assert decide_state(q01, q=10, s=0, a=0, v=0)[1] == 'NOT_SHOWN_APPROVED_ROUTE'
    assert decide_state(q09, q=10, s=10, a=10, v=8)[1] == 'UNKNOWN_ROUTE'
    assert decide_state(q01, q=10, s=10, a=10, v=0, refused=0, invalid=0)[1] == \
        'NON_SUBSTANTIVE_ONLY'
    assert decide_state(q01, q=10, s=10, a=10, v=0, refused=3, invalid=2)[1] == \
        'REFUSED_OR_CANNOT_JUDGE'
    assert decide_state(q01, q=10, s=10, a=10, v=5, floor=5)[1] == 'LOW_VALID_BASE'
    assert decide_state(q01, q=10, s=10, a=10, v=8)[1] == 'VALID_APPROVED'

    assert set(seen) == set(INSTRUMENT_GATES)
    assert set(seen.values()) == set(INSTRUMENT_GATES)


def test_low_valid_base_needs_an_approved_floor(registry):
    """Without a floor the state is not decidable, so it must not be asserted."""
    entry = _entry(registry, 'Q01')
    assert decide_state(entry, q=10, s=10, a=10, v=1)[1] == 'VALID_APPROVED'
    assert decide_state(entry, q=10, s=10, a=10, v=1, floor=2)[1] == 'LOW_VALID_BASE'


def test_unknown_route_outranks_refusals(registry):
    """An unadopted show gate cannot be reported as a refusal."""
    q09 = _entry(registry, 'Q09')
    assert q09.routing_resolved is False
    assert decide_state(q09, q=10, s=10, a=10, v=0, refused=4)[1] == 'UNKNOWN_ROUTE'


def test_gate_and_state_are_independent_axes(registry):
    entry = _entry(registry, 'Q05')
    gate, state = decide_state(entry, q=40, s=38, a=36, v=30)
    assert gate == 'MISSING_APPROVED_STIMULUS'
    assert state == 'VALID_APPROVED'
    assert effective_state(gate, state) == 'MISSING_APPROVED_STIMULUS'


def test_non_monotonic_counts_are_refused(registry):
    entry = _entry(registry, 'Q01')
    with pytest.raises(CqRefused) as exc:
        decide_state(entry, q=5, s=9, a=9, v=9)
    assert 'NOT_MONOTONIC' in str(exc.value)


# ------------------------------------------------------------------- rendering

@pytest.mark.parametrize('state', [
    'NOT_AUTHORIZED', 'BLOCKED_SOURCE', 'MISSING_APPROVED_STIMULUS',
    'MISSING_APPROVED_BANK', 'WITHDRAWN_OR_NO_CONSENT', 'NO_ADMISSIBLE_RESPONSES',
    'NOT_SHOWN_APPROVED_ROUTE', 'UNKNOWN_ROUTE',
])
def test_value_free_state_carries_no_figure(registry, state):
    """A value-free state must not leak a count through narrative."""
    entry = _entry(registry, 'Q01')
    rendered = render_question(registry, entry, gate=None, state=state,
                               question_id='Q01',
                               figures={'count': 7, 'shown': 41, 'V': 33},
                               missing=['GATE_A'])
    assert rendered['insufficient_evidence'] is True
    assert rendered['observation_interpretation']
    for token in ('7', '41', '33'):
        assert token not in rendered['observation_interpretation'].replace('Q01', '')


@pytest.mark.parametrize('state,expected', [
    ('NON_SUBSTANTIVE_ONLY', '7 of 41 shown respondents'),
    ('REFUSED_OR_CANNOT_JUDGE', '7 of 41 shown respondents'),
    ('LOW_VALID_BASE', 'Only 33 valid responses'),
])
def test_figure_bearing_states_report_exactly_the_supplied_figures(registry, state, expected):
    """These three owner sentences name a count by design; it must be the supplied one."""
    entry = _entry(registry, 'Q01')
    rendered = render_question(registry, entry, gate=None, state=state,
                               question_id='Q01',
                               figures={'count': 7, 'shown': 41, 'V': 33},
                               missing=['GATE_A'])
    assert expected in rendered['observation_interpretation']
    assert rendered['insufficient_evidence'] is True


def test_withheld_render_quotes_the_owner_state_sentence(registry):
    entry = _entry(registry, 'Q05')
    rendered = render_question(registry, entry, gate='MISSING_APPROVED_STIMULUS',
                               state='VALID_APPROVED', question_id='Q05',
                               figures={'count': 0, 'shown': 0, 'V': 0},
                               missing=['Q05'])
    assert rendered['state'] == 'MISSING_APPROVED_STIMULUS'
    assert rendered['observation_interpretation'].startswith(
        'Findings for Q05 are withheld because the instrument')
    assert entry.withheld.text in rendered['observation_interpretation']


def test_state_sentence_refuses_a_missing_figure(registry):
    with pytest.raises(CqRefused) as exc:
        state_sentence(registry, 'LOW_VALID_BASE', question_id='Q01', v=None)
    assert 'TEMPLATE_FIGURE_MISSING' in str(exc.value)


def test_valid_render_fills_the_item_template(registry):
    entry = _entry(registry, 'Q05')
    rendered = render_question(
        registry, entry, gate=None, state='VALID_APPROVED', question_id='Q05',
        figures={'V': 40, 'yes_count': 12, 'yes_percent': '30.0'}, missing=['CLAIM-1'])
    assert rendered['insufficient_evidence'] is False
    assert 'Among 40 valid respondents' in rendered['observation_interpretation']
    assert '12 (30.0%)' in rendered['observation_interpretation']
    assert entry.permitted_claim in rendered['research_interpretation']
    assert entry.limitation.text in rendered['limitations']
    assert rendered['templates_used'] == ['VD-Q05-APPROVED']


def test_valid_render_refuses_an_unknown_placeholder(registry):
    entry = _entry(registry, 'Q01')
    with pytest.raises(CqRefused) as exc:
        render_question(registry, entry, gate=None, state='VALID_APPROVED',
                        question_id='Q01', figures={'V': 10, 'count': 3})
    assert 'TEMPLATE_FIGURE_MISSING' in str(exc.value)


# -------------------------------------------------------------- guard widening

def test_registry_literals_contain_the_owner_tokens(registry):
    """The prose really does need the allowance; the tokens are the owner's."""
    for token in ('30', '100', '344', 'four', 'two', 'one', 'five'):
        assert token in registry.literals


def test_llm_path_still_rejects_a_quantity_word(registry):
    """The allowance must not be reachable from model output."""
    entry = _entry(registry, 'Q02')
    rendered = render_question(registry, entry, gate='NOT_AUTHORIZED',
                               state='VALID_APPROVED', question_id='Q02',
                               figures={'count': 0, 'shown': 0, 'V': 0},
                               missing=['Q02'])
    output = question_evidence_output(
        context_id='ctx', snapshot_id='snap', task_mode='CLAIM_EXPLANATION',
        rendered=rendered, used_claim_ids=[], missing=rendered['missing_evidence_references'])
    packet = {'task_mode': 'CLAIM_EXPLANATION', 'context_id': 'ctx',
              'snapshot_id': 'snap', 'reference_universe': ['Q02']}

    # With the allowance the owner's own sentence is accepted.
    validate_candidate(output, packet=packet, allowed_claim_ids=set(),
                       allowed_numbers=set(), registry_literals=registry.literals)
    # Without it — which is every model path — the same prose is refused.
    with pytest.raises(WorkflowHeld) as exc:
        validate_candidate(output, packet=packet, allowed_claim_ids=set(),
                           allowed_numbers=set())
    assert 'UNSOURCED_QUANTITY' in str(exc.value)


def test_registry_allowance_does_not_admit_an_arbitrary_number(registry):
    output = insufficient_evidence_output(context_id='ctx', snapshot_id='snap',
                                          task_mode='CLAIM_EXPLANATION', missing=['GATE'])
    poisoned = output.model_copy(update={
        'summary': 'The evidence covers 9876 respondents in total.'})
    packet = {'task_mode': 'CLAIM_EXPLANATION', 'context_id': 'ctx',
              'snapshot_id': 'snap', 'reference_universe': ['GATE']}
    with pytest.raises(WorkflowHeld) as exc:
        validate_candidate(poisoned, packet=packet, allowed_claim_ids=set(),
                           allowed_numbers=set(), registry_literals=registry.literals)
    assert 'UNSOURCED_NUMBER' in str(exc.value)


# ------------------------------------------------------------ service integration

def test_service_uses_the_question_template_for_a_resolved_slot():
    body = _explain(FakeEe01(slot_id='Q05'))
    assert body['producer'] == QUESTION_TEMPLATE_PRODUCER
    assert body['llm_execution'] == 'NOT_ATTEMPTED'
    assert body['authority'] == 'CANDIDATE_UNVERIFIED'
    assert body['report_release_authorized'] is False
    q = body['question']
    assert q['question_id'] == 'Q05'
    assert q['resolution_basis'] == 'DERIVED_FROM_SLOT_ID'
    assert q['instrument_gate'] == 'MISSING_APPROVED_STIMULUS'
    assert q['evidence_state'] == 'VALID_APPROVED'
    assert q['effective_state'] == 'MISSING_APPROVED_STIMULUS'
    assert q['template_usable_for_substantive_report'] is False
    candidate = body['candidate']
    assert candidate['insufficient_evidence'] is True
    assert candidate['used_claim_ids'] == []
    assert candidate['origin'] == 'DETERMINISTIC_TEMPLATE'


def test_service_binds_the_explanation_to_the_same_snapshot_as_the_chart():
    fake = FakeEe01(slot_id='Q05')
    body = _explain(fake)
    assert body['candidate']['snapshot_id'] == str(fake.snapshot_id)
    assert body['candidate']['context_id'] == fake.context_hash
    assert body['question']['registry_sha256'] == EXPECTED_REGISTRY_SHA256


def test_service_falls_back_to_the_generic_template_when_slot_is_unknown():
    body = _explain(FakeEe01(slot_id='NOT_A_QUESTION'))
    assert body['producer'] == TEMPLATE_PRODUCER
    assert body['question'] is None
    assert body['candidate']['insufficient_evidence'] is True


@pytest.fixture
def approved_registry(monkeypatch, registry):
    """The registry as it would read *after* an approval that has not happened.

    Every item carries an instrument gate today, so the substantive path is
    unreachable through the service. Clearing the gate in a patched copy exercises
    that path without asserting that any approval exists — the on-disk registry is
    untouched and its hash pin still fails closed.
    """
    import dataclasses

    entry = dataclasses.replace(registry.question('Q05'),
                                instrument_gate=None,
                                template_usable_for_substantive_report=True)
    patched = dataclasses.replace(registry,
                                  questions={**registry.questions, 'Q05': entry})
    monkeypatch.setattr(
        'sitewise.services.ee01_explanation_service.load_registry', lambda: patched)
    return patched


def test_service_holds_a_valid_state_without_an_authorized_finding(approved_registry):
    """A measurement exists but may not be interpreted: hold, never invent a claim."""
    with pytest.raises(CqRefused) as exc:
        _explain(FakeEe01(slot_id='Q05', q=40, s=38, a=36, v=30))
    assert 'EXPLANATION_FINDING_NOT_AUTHORIZED' in str(exc.value)


def test_service_renders_a_valid_state_with_a_bound_finding(approved_registry):
    finding = {'claim_id': 'CLAIM-Q05-TOP2', 'authorized': True,
               'status': 'AUTHORIZED', 'question_id': 'Q05',
               'label': 'Stated interest', 'construct': 'Q05_TOP_TWO_STATED_INTEREST',
               'count': 12, 'V': 40, 'yes_count': 12, 'yes_percent': '30.0'}
    body = _explain(FakeEe01(slot_id='Q05', findings=[dict(finding)]),
                    claim_ids=['CLAIM-Q05-TOP2'])
    assert body['producer'] == QUESTION_TEMPLATE_PRODUCER
    candidate = body['candidate']
    assert candidate['insufficient_evidence'] is False
    assert candidate['used_claim_ids'] == ['CLAIM-Q05-TOP2']
    assert 'Among 40 valid respondents' in candidate['observation_interpretation']
    assert '12 (30.0%)' in candidate['observation_interpretation']


def test_gate_outranks_a_substantive_measurement():
    """Today the gate always wins: a valid count cannot surface while unapproved."""
    body = _explain(FakeEe01(slot_id='Q05', q=40, s=38, a=36, v=30))
    assert body['question']['evidence_state'] == 'VALID_APPROVED'
    assert body['question']['effective_state'] == 'MISSING_APPROVED_STIMULUS'
    assert body['candidate']['insufficient_evidence'] is True
    assert body['question']['template_usable_for_substantive_report'] is False


@pytest.mark.parametrize('slot,gate', [
    ('Q01', 'NOT_AUTHORIZED'),
    ('Q03', 'BLOCKED_SOURCE'),
    ('Q05', 'MISSING_APPROVED_STIMULUS'),
    ('Q06', 'MISSING_APPROVED_BANK'),
    ('Q07', 'MISSING_APPROVED_STIMULUS'),
    ('Q10', 'MISSING_APPROVED_BANK'),
    ('Q11', 'NOT_AUTHORIZED'),
    ('Q13', 'NOT_AUTHORIZED'),
])
def test_every_item_reports_its_own_gate(slot, gate):
    body = _explain(FakeEe01(slot_id=slot))
    assert body['question']['instrument_gate'] == gate
    assert body['candidate']['insufficient_evidence'] is True


def test_service_output_passes_the_strict_validator_for_every_item(registry):
    """Registry prose must survive the real guard, for all thirteen items."""
    for question_id in registry.questions:
        body = _explain(FakeEe01(slot_id=question_id))
        output = ExplanationOutput(**body['candidate'])
        packet = {'task_mode': 'CLAIM_EXPLANATION',
                  'context_id': body['candidate']['context_id'],
                  'snapshot_id': body['candidate']['snapshot_id'],
                  'reference_universe': body['candidate']['missing_evidence_references']}
        validate_candidate(output, packet=packet, allowed_claim_ids=set(),
                           allowed_numbers=set(), registry_literals=registry.literals)


def test_service_never_emits_a_percentage_for_a_withheld_item():
    """Numerical fidelity: no share is computed anywhere in this path."""
    body = _explain(FakeEe01(slot_id='Q05', q=40, s=38, a=36, v=30))
    narrative = ' '.join(body['candidate'][field] for field in (
        'headline', 'observation_interpretation', 'research_interpretation',
        'planning_implication', 'limitations', 'summary'))
    assert '%' not in narrative
    assert ' of 40 ' not in narrative


def test_contract_version_advanced_for_the_registry_path():
    from sitewise.services.ee01_explanation_service import CONTRACT_VERSION
    assert CONTRACT_VERSION == 'ee01-explanation-candidate/3'
