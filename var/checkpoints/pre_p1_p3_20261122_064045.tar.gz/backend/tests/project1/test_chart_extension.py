"""CP3: chart-spec/1 beyond Q05.

The renderer and the contract are unchanged. What is new is coverage: the adapter
now reaches Q06, Q04, Q01, Q02, Q08 and Q09, presents the **draft** option label
bank that exists in the repository, and holds Q07 at
``UNAVAILABLE_MISSING_APPROVED_STIMULUS`` because no approved offer exists.

Two things this file deliberately proves rather than assumes:

* no chart produced here is report-admissible, for any question, at any count;
* Q10 is refused, not approximated, because a per-feature denominator cannot be
  expressed by EE-01 (recorded as ``CX-11``).
"""
from __future__ import annotations

import pytest

from chart_fixtures import load_question, readback, snapshot
from sitewise.project1.chart_question_source import (
    GATE_TO_RENDER_STATE,
    SUPPORTED_TYPES,
    source_for,
    supported_question_ids,
)
from sitewise.project1.chart_spec import ChartRefused, from_ee01

#: Questions CP3 must reach, with the report section(s) each one serves.
COVERED = {
    'Q01': ('R02', 'R08'),
    'Q02': ('R02', 'R08'),
    'Q04': ('R06',),
    'Q06': ('R04',),
    'Q07': ('R05',),
    'Q08': ('R07',),
    'Q09': ('R07',),
}


def counts_for(question_id: str) -> dict[str, int]:
    """A distinct, non-zero count per substantive code, in contract order."""
    codes = load_question(question_id)['substantive_codes']
    return {code: 3 + index for index, code in enumerate(codes)}


def build(question_id: str, *, counts=None, **snapshot_kwargs):
    source = source_for(question_id)
    snap = snapshot(question_id=question_id,
                    counts=counts_for(question_id) if counts is None else counts,
                    **snapshot_kwargs)
    spec = from_ee01(snap, readback(snap), source.question,
                     title=f'{question_id} test',
                     labels=source.labels,
                     render_state_override=source.render_state_override)
    return spec, source


# ------------------------------------------------------------------- coverage

def test_the_supported_set_covers_the_priority_questions():
    supported = set(supported_question_ids())
    assert set(COVERED) <= supported
    # Q11 and Q13 are structurally expressible but have no report section, so the
    # adapter still refuses them at the section check rather than at the type check.
    assert 'Q10' not in supported


def test_q10_matrix_is_refused_not_flattened():
    source = source_for('Q10')
    assert source.supported is False
    assert source.question['type'] == 'ordinal_matrix'
    snap = snapshot(question_id='Q10', counts=counts_for('Q10'))
    with pytest.raises(ChartRefused) as exc:
        from_ee01(snap, readback(snap), source.question, title='Q10',
                  labels=source.labels,
                  render_state_override=source.render_state_override)
    assert exc.value.code == 'CHART_RESPONSE_KIND_UNSUPPORTED'


@pytest.mark.parametrize('question_id', sorted(COVERED))
def test_each_question_maps_to_its_declared_sections(question_id):
    spec, source = build(question_id)
    assert spec.question_id == question_id
    assert tuple(spec.report_sections) == COVERED[question_id]
    assert spec.chart_id.endswith(COVERED[question_id][0])


@pytest.mark.parametrize('question_id', sorted(COVERED))
def test_no_chart_is_report_admissible(question_id):
    spec, _ = build(question_id)
    assert spec.admission.status == 'HELD'
    assert spec.admission.authority == 'AUTHORITY_UNVERIFIED'
    assert spec.admission.status != 'ADMITTED'
    assert spec.render_state != 'RENDERABLE'


@pytest.mark.parametrize('question_id', sorted(COVERED))
def test_no_percentage_is_emitted_anywhere(question_id):
    """Percentages require an adopted admission adapter, which does not exist."""
    spec, _ = build(question_id)
    assert all(option.percentage is None for option in spec.options)
    assert all(option.percentage_status != 'ESTIMABLE' for option in spec.options)
    assert all(line.percentage is None for line in spec.derived_lines)


@pytest.mark.parametrize('question_id', sorted(COVERED))
def test_response_kind_follows_the_contract_type(question_id):
    spec, source = build(question_id)
    expected = {
        'multi_select_with_exclusive_terminals': 'MULTI_SELECT',
        'multi_select': 'MULTI_SELECT',
        'ordinal_single': 'ORDINAL',
        'nominal_single': 'SINGLE_SELECT',
    }[source.question['type']]
    assert spec.response_kind == expected


# --------------------------------------------------------------------- labels

@pytest.mark.parametrize('question_id', sorted(COVERED))
def test_draft_labels_are_present_and_marked_as_drafts(question_id):
    spec, source = build(question_id)
    assert spec.options
    for option in spec.options:
        assert option.label, f'{question_id}/{option.code} lost its label'
        assert option.label_source == 'CONTRACT_OPTION_BANK_DRAFT'
        assert option.label == source.labels[option.code]


@pytest.mark.parametrize('question_id', sorted(COVERED))
def test_no_chart_claims_an_approved_label(question_id):
    spec, _ = build(question_id)
    assert all(option.label_source != 'CONTRACT_OPTION_BANK' for option in spec.options)


def test_encoding_defect_in_the_label_bank_is_repaired_not_shown():
    """`2â€“3 occasions` in the source must never reach a chart label."""
    spec, _ = build('Q04')
    labels = {option.code: option.label for option in spec.options}
    assert labels['TWO_THREE'] == '2\u20133 occasions'
    for label in labels.values():
        assert '\u00e2\u20ac' not in label


def test_a_code_without_a_label_falls_back_to_the_code():
    source = source_for('Q06')
    trimmed = {k: v for k, v in source.labels.items() if k != 'RETAIL'}
    snap = snapshot(question_id='Q06', counts=counts_for('Q06'))
    spec = from_ee01(snap, readback(snap), source.question, title='Q06',
                     labels=trimmed)
    option = next(o for o in spec.options if o.code == 'RETAIL')
    assert option.label is None
    assert option.label_source == 'CODE_FALLBACK'


def test_no_labels_argument_keeps_the_previous_behaviour():
    snap = snapshot()
    spec = from_ee01(snap, readback(snap), load_question('Q05'), title='Q05')
    assert all(o.label is None and o.label_source == 'CODE_FALLBACK' for o in spec.options)


# ------------------------------------------------------------ ordinal meaning

def test_only_q05_declares_an_ordinal_scale():
    """Q02, Q04, Q07 and Q13 are typed ordinal but declare no scale mapping.

    Recorded as ``CX-18``. The chart therefore presents ordered categories with
    no ordinal value and no interval claim; display order is never read as a
    scale.
    """
    for question_id in ('Q02', 'Q04', 'Q07'):
        spec, source = build(question_id)
        assert source.question.get('ordinal_meaning') is None
        assert all(o.ordinal_value is None for o in spec.options), question_id
    spec, source = build('Q05')
    assert source.question.get('ordinal_meaning') is not None
    assert [o.ordinal_value for o in spec.options if o.code in
            ('DEF_NO', 'PROB_NO', 'UNSURE', 'PROB_YES', 'DEF_YES')] == [1, 2, 3, 4, 5]


def test_multi_select_questions_carry_no_ordinal_meaning():
    for question_id in ('Q01', 'Q06', 'Q08', 'Q09'):
        spec, _ = build(question_id)
        assert all(o.ordinal_value is None for o in spec.options), question_id


# --------------------------------------------------------------- held Q07

def test_q07_is_held_for_a_missing_approved_offer():
    source = source_for('Q07')
    assert source.gate == 'MISSING_APPROVED_STIMULUS'
    assert source.render_state_override == 'UNAVAILABLE_MISSING_APPROVED_STIMULUS'
    spec, _ = build('Q07')
    assert spec.render_state == 'UNAVAILABLE_MISSING_APPROVED_STIMULUS'
    assert spec.admission.status == 'HELD'
    assert all(o.percentage is None for o in spec.options)
    assert spec.highest_options == []


def test_q07_held_notice_never_reads_as_zero_acceptability():
    """R05's contract forbids presenting the absence as zero or as a WTP band."""
    spec, _ = build('Q07')
    text = ' '.join(spec.limitations).lower()
    assert 'zero acceptability' not in text
    assert '%' not in ' '.join(spec.limitations)


def test_q05_and_q06_are_held_for_their_own_missing_inputs():
    assert source_for('Q05').render_state_override == 'UNAVAILABLE_MISSING_APPROVED_STIMULUS'
    assert source_for('Q06').render_state_override == 'UNAVAILABLE_MISSING_APPROVED_STIMULUS'


def test_a_gate_that_only_blocks_approval_leaves_the_state_to_the_snapshot():
    assert source_for('Q01').gate == 'NOT_AUTHORIZED'
    assert source_for('Q01').render_state_override is None
    spec, _ = build('Q01')
    assert spec.render_state == 'WITHHELD_NOT_AUTHORIZED'


# ------------------------------------------------------------------ override

def test_an_override_cannot_manufacture_admission():
    snap = snapshot()
    with pytest.raises(ChartRefused) as exc:
        from_ee01(snap, readback(snap), load_question('Q05'), title='Q05',
                  render_state_override='RENDERABLE')
    assert exc.value.code == 'CHART_OVERRIDE_CANNOT_AUTHORIZE'


def test_an_unknown_override_is_refused():
    snap = snapshot()
    with pytest.raises(ChartRefused) as exc:
        from_ee01(snap, readback(snap), load_question('Q05'), title='Q05',
                  render_state_override='ADMITTED')
    assert exc.value.code == 'CHART_OVERRIDE_UNKNOWN'


def test_every_gate_maps_to_a_permitted_restriction():
    allowed = {None, 'NOT_SHOWN', 'NOT_ESTIMABLE', 'WITHHELD_NOT_AUTHORIZED',
               'UNAVAILABLE_MISSING_APPROVED_STIMULUS', 'UNAUTHORIZED_CLAIM'}
    assert set(GATE_TO_RENDER_STATE.values()) <= allowed


# --------------------------------------------------------- structural gaps

def test_an_item_with_no_report_section_is_refused():
    """Q11 and Q13 are expressible but unassigned, so they cannot be charted."""
    for question_id in ('Q11', 'Q13'):
        source = source_for(question_id)
        assert source.report_sections == ()
        snap = snapshot(question_id=question_id, counts=counts_for(question_id))
        with pytest.raises(ChartRefused) as exc:
            from_ee01(snap, readback(snap), source.question, title=question_id,
                      labels=source.labels)
        assert exc.value.code == 'CHART_REPORT_SECTION_MISSING'


def test_an_unknown_question_is_refused():
    with pytest.raises(ChartRefused) as exc:
        source_for('Q99')
    assert exc.value.code == 'CHART_QUESTION_UNKNOWN'


def test_derived_lines_stay_q05_only():
    for question_id in ('Q01', 'Q02', 'Q04', 'Q06', 'Q08', 'Q09'):
        spec, _ = build(question_id)
        assert spec.derived_lines == [], question_id
    spec, _ = build('Q05')
    assert [line.code for line in spec.derived_lines] == ['TOP_TWO_STATED_INTEREST']


def test_the_supported_types_are_the_ones_the_contract_can_express():
    assert SUPPORTED_TYPES == {
        'single_select', 'nominal_single', 'multi_select',
        'multi_select_with_exclusive_terminals', 'ordinal_single',
    }
    assert 'ordinal_matrix' not in SUPPORTED_TYPES
