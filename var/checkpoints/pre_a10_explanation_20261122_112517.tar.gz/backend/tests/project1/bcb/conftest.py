"""Only the preserved synthetic BCB support directory is added to test imports."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent))
