"""CP5: report integration, snapshot reproducibility and the thirteen E2E cases.

Three properties are verified here.

**Integration, not expansion.** The report keeps exactly the R01–R12 sections the
instrument defines. Nothing in this work adds a section; the chart and the
explanation feed the sections that already exist, and each section reports its
own disposition.

**Reproducibility.** Reopening a report must not re-run EE-01 and must not call a
language model. Both are asserted by instrumenting the EE-01 double: the
measurement builder is never invoked by the explanation path, and two reads of the
same snapshot produce byte-identical candidates.

**Immutability.** No module touched by this work writes to a report, an admission
table or any durable store. That is asserted structurally, by checking the
modules' own source for write verbs, because a behavioural test cannot prove the
absence of a path it never takes.

The thirteen cases are one per item, so a failure names the item.
"""
from __future__ import annotations

import inspect
import json
from uuid import uuid4

import pytest

from chart_fixtures import readback, snapshot
from sitewise.domain.cq_runtime import CqRefused
from sitewise.project1 import chart_question_source, chart_spec, explanation_registry
from sitewise.project1.chart_question_source import source_for
from sitewise.project1.chart_spec import ChartRefused, from_ee01
from sitewise.project1.explanation_registry import (
    decide_state,
    effective_state,
    load_registry,
)
from sitewise.services.ee01_explanation_service import (
    QUESTION_TEMPLATE_PRODUCER,
    Ee01ExplanationService,
)

ALL_QUESTIONS = [f'Q{n:02d}' for n in range(1, 14)]

#: The expected disposition of every item at this checkpoint. Derived from the
#: registry and the chart adapter; recorded explicitly so a change is visible.
EXPECTED = {
    'Q01': {'chart': 'WITHHELD_NOT_AUTHORIZED', 'gate': 'NOT_AUTHORIZED',
            'sections': ('R02', 'R08'), 'chart_refusal': None},
    'Q02': {'chart': 'WITHHELD_NOT_AUTHORIZED', 'gate': 'NOT_AUTHORIZED',
            'sections': ('R02', 'R08'), 'chart_refusal': None},
    'Q03': {'chart': 'WITHHELD_NOT_AUTHORIZED', 'gate': 'BLOCKED_SOURCE',
            'sections': ('R08',), 'chart_refusal': None},
    'Q04': {'chart': 'WITHHELD_NOT_AUTHORIZED', 'gate': 'NOT_AUTHORIZED',
            'sections': ('R06',), 'chart_refusal': None},
    'Q05': {'chart': 'UNAVAILABLE_MISSING_APPROVED_STIMULUS',
            'gate': 'MISSING_APPROVED_STIMULUS',
            'sections': ('R03',), 'chart_refusal': None},
    'Q06': {'chart': 'UNAVAILABLE_MISSING_APPROVED_STIMULUS',
            'gate': 'MISSING_APPROVED_BANK',
            'sections': ('R04',), 'chart_refusal': None},
    'Q07': {'chart': 'UNAVAILABLE_MISSING_APPROVED_STIMULUS',
            'gate': 'MISSING_APPROVED_STIMULUS',
            'sections': ('R05',), 'chart_refusal': None},
    'Q08': {'chart': 'WITHHELD_NOT_AUTHORIZED', 'gate': 'BLOCKED_SOURCE',
            'sections': ('R07',), 'chart_refusal': None},
    'Q09': {'chart': 'WITHHELD_NOT_AUTHORIZED', 'gate': 'BLOCKED_SOURCE',
            'sections': ('R07',), 'chart_refusal': None},
    'Q10': {'chart': None, 'gate': 'MISSING_APPROVED_BANK',
            'sections': ('R07',), 'chart_refusal': 'CHART_RESPONSE_KIND_UNSUPPORTED'},
    'Q11': {'chart': None, 'gate': 'NOT_AUTHORIZED',
            'sections': (), 'chart_refusal': 'CHART_REPORT_SECTION_MISSING'},
    'Q12': {'chart': 'WITHHELD_NOT_AUTHORIZED', 'gate': 'NOT_AUTHORIZED',
            'sections': ('R08',), 'chart_refusal': None},
    'Q13': {'chart': None, 'gate': 'NOT_AUTHORIZED',
            'sections': (), 'chart_refusal': 'CHART_REPORT_SECTION_MISSING'},
}


def counts_for(question_id: str) -> dict[str, int]:
    from chart_fixtures import load_question
    codes = load_question(question_id)['substantive_codes']
    return {code: 3 + index for index, code in enumerate(codes)}


class RecordingEe01:
    """EE-01 double that records which operations ran and whether it was written to."""

    def __init__(self, *, slot_id='Q05', q=40, s=38, a=36, v=30):
        self.assessment_id = uuid4()
        self.campaign_id = uuid4()
        self.snapshot_id = uuid4()
        self.slot_id = slot_id
        self.calls = []
        self.writes = []
        self.counts = {'ANSWERED_SUBSTANTIVE': v, 'ANSWERED_NON_SUBSTANTIVE': a - v,
                       'REFUSED': 2, 'INVALID': 4, 'SKIPPED': s - a,
                       'SHOWN_NO_ANSWER': 0, 'not_shown': q - s, 'excluded': 0}
        self.context = {
            'snapshot_id': str(self.snapshot_id), 'fingerprint': 'a' * 64,
            'assessment_id': str(self.assessment_id), 'campaign_id': str(self.campaign_id),
            'source_hash': 'b' * 64, 'rules_hash': 'c' * 64,
            'authority': 'AUTHORITY_UNVERIFIED', 'findings': [],
            'gates': ['EXPLANATION_TEMPLATE_AUTHORITY_UNVERIFIED',
                      'A10_ADAPTER_UNVERIFIED', 'REPORT_ADMISSION_REQUIRED'],
        }
        from sitewise.domain.customer_questionnaire import digest
        self.context_hash = digest(self.context)
        self._counts = (q, s, a, v)

    def build_diagnostic(self, *args, **kwargs):  # pragma: no cover - must not run
        self.calls.append('build_diagnostic')
        raise AssertionError('EE-01 measurement was re-run during a report read')

    def report_readback(self, actor, aid, cid, sid):
        self.calls.append('report_readback')
        return {'status': 'REPORT_FINDINGS_WITHHELD_NO_AUTHORIZED_SOURCE',
                'context_hash': self.context_hash, 'context': dict(self.context),
                'findings': []}

    def read(self, actor, aid, cid, sid):
        self.calls.append('read')
        q, s, a, v = self._counts
        return {'id': self.snapshot_id, 'assessment_id': self.assessment_id,
                'campaign_id': self.campaign_id, 'question_version': f'{self.slot_id}@1',
                'slot_id': self.slot_id, 'fingerprint': 'a' * 64, 'scope': 'ISOLATED_TEST',
                'q': q, 's': s, 'a': a, 'v': v,
                'counts_json': json.dumps(self.counts),
                'metadata_json': {'instrument_version': 'SYN-1', 'bank_version': 'SYN-B',
                                  'routing_version': 'SYN-P', 'consent_version': 'SYN-C',
                                  'qualification_versions': ['SYN-Q'],
                                  'privacy_policy': 'WITHHOLD_ALL_FINDINGS',
                                  'rule': 'CUST03_CURRENT_ATTEMPT_DIAGNOSTIC',
                                  'selection': 'LATEST_ATTEMPT',
                                  'cutoff_basis': 'SNAPSHOT',
                                  'scientific_gaps': ['A_DEFINITION_UNRESOLVED']},
                'cells': []}


def explain(fake, **kwargs):
    return Ee01ExplanationService(fake).explain(
        uuid4(), fake.assessment_id, fake.campaign_id, fake.snapshot_id,
        task_mode='CLAIM_EXPLANATION', claim_ids=[], context_hash=fake.context_hash,
        **kwargs)


def chart_for(question_id):
    """Return ``(spec, refusal_code)`` for one item."""
    source = source_for(question_id)
    snap = snapshot(question_id=question_id, counts=counts_for(question_id))
    try:
        spec = from_ee01(snap, readback(snap), source.question,
                         title=f'{question_id} report section',
                         labels=source.labels,
                         render_state_override=source.render_state_override)
    except ChartRefused as exc:
        return None, exc.code
    return spec, None


# ============================================================ thirteen cases

def _assert_case(question_id):
    expected = EXPECTED[question_id]

    # --- chart -------------------------------------------------------------
    spec, refusal = chart_for(question_id)
    assert refusal == expected['chart_refusal'], question_id
    if spec is not None:
        assert spec.render_state == expected['chart'], question_id
        assert spec.render_state != 'RENDERABLE', question_id
        assert spec.admission.status == 'HELD', question_id
        assert all(o.percentage is None for o in spec.options), question_id
        assert tuple(spec.report_sections) == expected['sections'], question_id

    # --- explanation -------------------------------------------------------
    fake = RecordingEe01(slot_id=question_id)
    body = explain(fake)
    assert body['question']['instrument_gate'] == expected['gate'], question_id
    assert body['question']['effective_state'] == expected['gate'], question_id
    assert body['producer'] == QUESTION_TEMPLATE_PRODUCER, question_id
    assert body['candidate']['insufficient_evidence'] is True, question_id
    assert body['candidate']['used_claim_ids'] == [], question_id
    assert body['report_release_authorized'] is False, question_id
    assert body['scientific_acceptance'] is False, question_id
    assert body['authority'] == 'CANDIDATE_UNVERIFIED', question_id

    # --- report section disposition ---------------------------------------
    registry = load_registry()
    entry = registry.question(question_id)
    assert entry.report_sections == expected['sections'], question_id
    assert entry.template_usable_for_substantive_report is False, question_id

    # --- no figure leaked anywhere ----------------------------------------
    narrative = ' '.join(body['candidate'][field] for field in (
        'headline', 'observation_interpretation', 'research_interpretation',
        'planning_implication', 'limitations', 'summary'))
    assert '%' not in narrative, question_id


def test_e2e_q01_area_affiliation():
    _assert_case('Q01')


def test_e2e_q02_area_presence_frequency():
    _assert_case('Q02')


def test_e2e_q03_origin_type():
    _assert_case('Q03')


def test_e2e_q04_existing_use():
    _assert_case('Q04')


def test_e2e_q05_concept_intent():
    _assert_case('Q05')


def test_e2e_q06_product_interest():
    _assert_case('Q06')


def test_e2e_q07_price_acceptability():
    _assert_case('Q07')


def test_e2e_q08_past_occasion():
    _assert_case('Q08')


def test_e2e_q09_planned_occasion():
    _assert_case('Q09')


def test_e2e_q10_experience_priority():
    _assert_case('Q10')


def test_e2e_q11_service_format():
    _assert_case('Q11')


def test_e2e_q12_transport_mode():
    _assert_case('Q12')


def test_e2e_q13_price_expectation():
    _assert_case('Q13')


# ====================================================== reproducibility

def test_reopening_a_report_does_not_rerun_ee01():
    """The explanation path reads stored rows; it never rebuilds the measurement."""
    fake = RecordingEe01(slot_id='Q05')
    explain(fake)
    assert 'build_diagnostic' not in fake.calls
    assert fake.calls == ['report_readback', 'read']


def test_reopening_a_report_is_byte_identical():
    fake = RecordingEe01(slot_id='Q05')
    first = explain(fake)
    second = explain(fake)
    assert first['candidate'] == second['candidate']
    assert first['question'] == second['question']
    assert 'build_diagnostic' not in fake.calls


def test_no_language_model_is_contacted_without_a_disclosure_adapter():
    """No candidate source is wired, so the model path is never attempted."""
    fake = RecordingEe01(slot_id='Q05')
    body = explain(fake)
    assert body['llm_execution'] == 'NOT_ATTEMPTED'
    assert body['prompt_version'] is None
    assert body['candidate']['origin'] == 'DETERMINISTIC_TEMPLATE'


def test_a_report_read_writes_nothing():
    """The EE-01 double records writes; the read path performs none."""
    fake = RecordingEe01(slot_id='Q05')
    explain(fake)
    assert fake.writes == []


@pytest.mark.parametrize('module', [
    explanation_registry,
    chart_spec,
    chart_question_source,
])
def test_touched_modules_contain_no_durable_write(module):
    """Structural proof that no new path can persist a report or admission row."""
    source = inspect.getsource(module)
    for verb in ('INSERT INTO', 'UPDATE ', 'DELETE FROM', 'commit(', 'session.add',
                 'write_text', 'open(', 'to_sql'):
        assert verb not in source, f'{module.__name__} contains {verb!r}'


def test_the_explanation_module_writes_nothing_either():
    from sitewise.services import ee01_explanation_service as service
    source = inspect.getsource(service)
    for verb in ('INSERT INTO', 'UPDATE ee01', 'DELETE FROM', 'commit('):
        assert verb not in source, f'{verb!r} found in the explanation service'


# ================================================ report section integrity

def test_the_report_keeps_exactly_the_twelve_canonical_sections():
    assert chart_spec.CANONICAL_REPORT_SECTIONS == tuple(f'R{n:02d}' for n in range(1, 13))


def test_no_item_is_mapped_to_a_non_canonical_section():
    registry = load_registry()
    for entry in registry.questions.values():
        for section in entry.report_sections:
            assert section in chart_spec.CANONICAL_REPORT_SECTIONS, entry.question_id


def test_every_rendered_chart_targets_a_section_its_item_declares():
    for question_id in ALL_QUESTIONS:
        spec, refusal = chart_for(question_id)
        if spec is None:
            continue
        entry = load_registry().question(question_id)
        assert tuple(spec.report_sections) == entry.report_sections, question_id


def test_administrative_sections_never_admit_a_measurement():
    """R02 and R12 are renderable but carry requires_V: false."""
    registry = load_registry()
    for entry in registry.questions.values():
        for section, detail in entry.report_admission['sections'].items():
            if detail['administrative_only']:
                assert detail['may_render_measurement'] is False


def test_r11_is_never_renderable_and_no_item_targets_it():
    """R11 is NEVER in the instrument: no authorised overall suitability verdict."""
    assert 'R11' in chart_spec.CANONICAL_REPORT_SECTIONS
    registry = load_registry()
    for entry in registry.questions.values():
        assert 'R11' not in entry.report_sections, entry.question_id


# ============================================ historical-report immutability

def test_the_readback_context_is_not_mutated_by_a_report_read():
    """A report read must leave the stored context exactly as it found it."""
    fake = RecordingEe01(slot_id='Q05')
    before = json.dumps(fake.context, sort_keys=True)
    explain(fake)
    assert json.dumps(fake.context, sort_keys=True) == before


def test_the_explanation_service_exposes_no_write_method():
    """Structural: there is no method by which a report could be rewritten."""
    public = [name for name in dir(Ee01ExplanationService) if not name.startswith('__')]
    for name in public:
        assert not any(verb in name.lower() for verb in
                       ('write', 'save', 'persist', 'publish', 'release', 'admit',
                        'commit', 'update', 'delete')), name


def test_historical_admitted_reports_are_immutable_by_construction():
    """Recorded as structural, because no admitted report exists to test against.

    No module in this work holds a reference to a report row and none performs a
    write, so there is no path by which a historical report could be rewritten.
    A behavioural test cannot prove the absence of a path that was never taken, so
    the check is stated as what it is: a structural property.
    """
    for module in (explanation_registry, chart_spec, chart_question_source):
        source = inspect.getsource(module)
        for forbidden in ('report_release', 'report_rows', 'published_report',
                          'report_versions'):
            assert forbidden not in source, f'{module.__name__} touches {forbidden!r}'


def test_no_admitted_status_exists_in_the_codebase():
    """`ADMITTED` must be unreachable, not merely unused."""
    registry = load_registry()
    for entry in registry.questions.values():
        assert entry.template_usable_for_substantive_report is False
    spec, _ = chart_for('Q01')
    assert spec.admission.status == 'HELD'
    assert spec.admission.status != 'ADMITTED'
