"""Unit tests for the synthetic-only O1-O6 objective-obligation evaluator.

These tests are ENGINEERING ONLY. The registry below is a *synthetic approved
manifest* fixture: its construct ids are suffixed ``_SYN`` and its approvals are
fabricated for the test. They do NOT represent scientific approval of the real
constructs, and nothing here activates a real measurement.

Run from ``backend/``:
    python -m pytest tests/cq_runtime/test_objective_runtime.py -q
"""
from __future__ import annotations

import pytest

from sitewise.domain.objective_runtime import (
    HOLD_RELEASE_OBJECTIVE_COVERAGE,
    APPROVED,
    OBJECTIVE_BRANCH_RESOLVED,
    OUTSTANDING,
    RESOLVED_BY_AUTHORISED_NONRESPONSE,
    SKIP_NOT_APPLICABLE,
    ObjectiveObligation,
    evaluate,
)

# Synthetic fixtures opt in to APPROVED explicitly; the production default is
# fail-closed (NOT_AUTHORIZED), so this helper is the only place a test grants it.
def OB(objective_id, construct_id, slots, **kw):
    kw.setdefault("construct_status", APPROVED)
    return ObjectiveObligation(objective_id, construct_id, slots, **kw)


# ---------------------------------------------------------------------------
# Synthetic approved-manifest fixture (engineering only, NOT science)
# ---------------------------------------------------------------------------
SYNTHETIC_SLOT_CONSTRUCTS = {
    "Q05": "D01_CONCEPT_INTENT_SYN",
    "Q06": "D02_PRODUCT_INTEREST_SYN",
    "Q07": "D03A_PRICE_ACCEPT_SYN",
    "Q11": "FMT01_FORMAT_CHOICE_SYN",
    "Q10:FEAT_A": "D06_EXPERIENCE_PRIORITY_SYN",
    "Q10:FEAT_B": "D06_EXPERIENCE_PRIORITY_SYN",
    "SEG01": "SEG01_SEGMENT_SYN",
}


def synthetic_obligations():
    """Six mandatory objectives, all constructs synthetically APPROVED."""
    return [
        OB("O1", "D01_CONCEPT_INTENT_SYN", ("Q05",)),
        OB("O2", "D02_PRODUCT_INTEREST_SYN", ("Q06",)),
        OB(
            "O3",
            "D03A_PRICE_ACCEPT_SYN",
            ("Q07",),
            nonresponse_codes=frozenset({"CANNOT_JUDGE"}),
        ),
        OB("O4", "FMT01_FORMAT_CHOICE_SYN", ("Q11",)),
        OB(
            "O5",
            "D06_EXPERIENCE_PRIORITY_SYN",
            ("Q10:FEAT_A", "Q10:FEAT_B"),
            applicability={"fact": "CAFE_VISIT_CONTEXT", "equals": True},
        ),
        OB("O6", "SEG01_SEGMENT_SYN", ("SEG01",)),
    ]


def ans(state, event_id="evt", value=None):
    return {"state": state, "value": value, "event_id": event_id}


def full_answers():
    return {
        "Q05": ans("ANSWERED_SUBSTANTIVE", "e05", ["PROB_YES"]),
        "Q06": ans("ANSWERED_SUBSTANTIVE", "e06", ["COFFEE_ESPRESSO"]),
        "Q07": ans("ANSWERED_SUBSTANTIVE", "e07", ["SOMEWHAT_ACCEPTABLE"]),
        "Q11": ans("ANSWERED_SUBSTANTIVE", "e11", ["TAKEAWAY"]),
        "Q10:FEAT_A": ans("ANSWERED_SUBSTANTIVE", "e10a", ["VERY_IMPORTANT"]),
        "SEG01": ans("ANSWERED_SUBSTANTIVE", "eseg", ["SEG_A"]),
    }


# ---------------------------------------------------------------------------
# 1. All six resolve with substantive answers
# ---------------------------------------------------------------------------
def test_all_six_resolve_when_substantive():
    result = evaluate(
        synthetic_obligations(),
        effective_answers=full_answers(),
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
        facts={"CAFE_VISIT_CONTEXT": True},
    )
    assert result.final_ready is True
    assert set(result.resolved_ids) == {"O1", "O2", "O3", "O4", "O5", "O6"}
    assert all(r.status == OBJECTIVE_BRANCH_RESOLVED for r in result.resolutions)


# ---------------------------------------------------------------------------
# 2. A negative answer is still valid evidence (no screen-out)
# ---------------------------------------------------------------------------
def test_negative_answer_resolves_o1():
    answers = full_answers()
    answers["Q05"] = ans("ANSWERED_SUBSTANTIVE", "e05", ["DEF_NO"])
    result = evaluate(
        synthetic_obligations(),
        effective_answers=answers,
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
        facts={"CAFE_VISIT_CONTEXT": True},
    )
    assert result.resolution("O1").status == OBJECTIVE_BRANCH_RESOLVED


# ---------------------------------------------------------------------------
# 3. Authorised nonresponse resolves only when declared
# ---------------------------------------------------------------------------
def test_authorised_nonresponse_resolves_o3():
    answers = full_answers()
    answers["Q07"] = ans("ANSWERED_NON_SUBSTANTIVE", "e07", ["CANNOT_JUDGE"])
    result = evaluate(
        synthetic_obligations(),
        effective_answers=answers,
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
        facts={"CAFE_VISIT_CONTEXT": True},
    )
    assert result.resolution("O3").status == RESOLVED_BY_AUTHORISED_NONRESPONSE


def test_undeclared_nonresponse_does_not_resolve():
    answers = full_answers()
    answers["Q07"] = ans("ANSWERED_NON_SUBSTANTIVE", "e07", ["CANNOT_JUDGE"])
    obligations = [
        OB("O3", "D03A_PRICE_ACCEPT_SYN", ("Q07",))  # no nonresponse codes
    ]
    result = evaluate(
        obligations,
        effective_answers=answers,
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
    )
    assert result.resolution("O3").status == OUTSTANDING


# ---------------------------------------------------------------------------
# 4. A shared question must not prove a construct it does not measure
# ---------------------------------------------------------------------------
def test_shared_slot_cannot_resolve_a_construct_it_does_not_measure():
    # O2 is (wrongly) pointed at Q05, which the manifest says measures O1.
    obligations = [OB("O2", "D02_PRODUCT_INTEREST_SYN", ("Q05",))]
    result = evaluate(
        obligations,
        effective_answers=full_answers(),
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
    )
    resolution = result.resolution("O2")
    assert resolution.status == OUTSTANDING
    assert resolution.reason == "SLOT_MEASURES_DIFFERENT_CONSTRUCT"


# ---------------------------------------------------------------------------
# 5. Dependent-item skip
# ---------------------------------------------------------------------------
def test_inapplicable_objective_is_skipped_not_resolved():
    result = evaluate(
        synthetic_obligations(),
        effective_answers=full_answers(),
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
        facts={"CAFE_VISIT_CONTEXT": False},
    )
    assert result.resolution("O5").status == SKIP_NOT_APPLICABLE
    # A skipped mandatory objective does not block final readiness.
    assert result.final_ready is True


# ---------------------------------------------------------------------------
# 6. Final submission blocked while an objective is outstanding
# ---------------------------------------------------------------------------
def test_outstanding_blocks_final_readiness():
    answers = full_answers()
    del answers["Q07"]
    result = evaluate(
        synthetic_obligations(),
        effective_answers=answers,
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
        facts={"CAFE_VISIT_CONTEXT": True},
    )
    assert result.final_ready is False
    assert "O3" in result.outstanding
    assert result.resolution("O3").status == OUTSTANDING


# ---------------------------------------------------------------------------
# 7. A blocked construct holds the release, even if an answer exists
# ---------------------------------------------------------------------------
def test_blocked_construct_holds_release():
    obligations = synthetic_obligations()
    obligations[2] = OB(
        "O3",
        "D03A_PRICE_ACCEPT_SYN",
        ("Q07",),
        construct_status="BLOCKED_MEASUREMENT",
    )
    result = evaluate(
        obligations,
        effective_answers=full_answers(),
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
        facts={"CAFE_VISIT_CONTEXT": True},
    )
    assert result.resolution("O3").status == HOLD_RELEASE_OBJECTIVE_COVERAGE
    assert result.final_ready is False
    assert "O3" in result.held


# ---------------------------------------------------------------------------
# 8. Missing / withheld question never resolves an objective
# ---------------------------------------------------------------------------
def test_missing_question_never_resolves():
    result = evaluate(
        [OB("O1", "D01_CONCEPT_INTENT_SYN", ("Q05",))],
        effective_answers={},
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
    )
    assert result.resolution("O1").status == OUTSTANDING
    assert result.final_ready is False


# ---------------------------------------------------------------------------
# 9. Refused without declaration is not evidence
# ---------------------------------------------------------------------------
def test_refused_without_declaration_is_outstanding():
    answers = {"Q05": ans("REFUSED", "e05", [])}
    result = evaluate(
        [OB("O1", "D01_CONCEPT_INTENT_SYN", ("Q05",))],
        effective_answers=answers,
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
    )
    assert result.resolution("O1").status == OUTSTANDING


# ---------------------------------------------------------------------------
# 10. Registry validation
# ---------------------------------------------------------------------------
def test_empty_slots_rejected():
    with pytest.raises(ValueError):
        OB("O1", "X_SYN", ())


# ---------------------------------------------------------------------------
# 11. D-1 regression: a not-ready measurement is HOLD, never a skip.
#     (Release readiness must not be encoded as respondent applicability.)
# ---------------------------------------------------------------------------
def test_blocked_construct_holds_even_with_answer():
    obligations = [
        OB(
            "O5",
            "D06_EXPERIENCE_PRIORITY_SYN",
            ("Q10:FEAT_A",),
            construct_status="G06_APPROVAL_PENDING",
        )
    ]
    result = evaluate(
        obligations,
        effective_answers=full_answers(),
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
    )
    assert result.resolution("O5").status == HOLD_RELEASE_OBJECTIVE_COVERAGE
    assert result.final_ready is False


# ---------------------------------------------------------------------------
# 12. D-2: a non-mandatory outstanding objective does not block readiness.
# ---------------------------------------------------------------------------
def test_non_mandatory_outstanding_does_not_block():
    obligations = [
        OB("O1", "D01_CONCEPT_INTENT_SYN", ("Q05",)),
        OB(
            "O4", "FMT01_FORMAT_CHOICE_SYN", ("Q11",), mandatory=False
        ),
    ]
    answers = {"Q05": ans("ANSWERED_SUBSTANTIVE", "e05", ["PROB_YES"])}
    result = evaluate(
        obligations,
        effective_answers=answers,
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
    )
    assert result.resolution("O4").status == OUTSTANDING
    assert result.final_ready is True


# ---------------------------------------------------------------------------
# 13. D-3: real contract status tokens are accepted and fail closed to HOLD.
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    "status",
    ["PENDING_SCIENTIFIC", "PENDING_OWNER", "G06_APPROVAL_PENDING", "NOT_ADOPTED", "BLOCKED_SOURCE"],
)
def test_real_contract_tokens_fail_closed(status):
    obligations = [
        OB("O1", "D01_CONCEPT_INTENT_SYN", ("Q05",), construct_status=status)
    ]
    result = evaluate(
        obligations,
        effective_answers=full_answers(),
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
    )
    assert result.resolution("O1").status == HOLD_RELEASE_OBJECTIVE_COVERAGE
    assert result.final_ready is False


# ---------------------------------------------------------------------------
# 14. D-4: objectives never substitute for the common core (can_submit).
# ---------------------------------------------------------------------------
def test_common_core_required_for_final_readiness():
    result = evaluate(
        synthetic_obligations(),
        effective_answers=full_answers(),
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
        facts={"CAFE_VISIT_CONTEXT": True},
        common_core_ready=False,
    )
    assert result.final_ready is False


# ---------------------------------------------------------------------------
# 15. S-5: resolution is bound to the context digest; a superseded answer
#     (e.g. after an edit changed the dependency context) must not resolve.
# ---------------------------------------------------------------------------
def test_stale_context_answer_does_not_resolve():
    answers = {
        "Q05": {
            "state": "ANSWERED_SUBSTANTIVE",
            "value": ["PROB_YES"],
            "event_id": "e05",
            "context_digest": "OLD_DIGEST",
        }
    }
    result = evaluate(
        [OB("O1", "D01_CONCEPT_INTENT_SYN", ("Q05",))],
        effective_answers=answers,
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
        slot_contexts={"Q05": "CURRENT_DIGEST"},
    )
    assert result.resolution("O1").status == OUTSTANDING


def test_matching_context_answer_resolves_and_records_digest():
    answers = {
        "Q05": {
            "state": "ANSWERED_SUBSTANTIVE",
            "value": ["PROB_YES"],
            "event_id": "e05",
            "context_digest": "CURRENT_DIGEST",
        }
    }
    result = evaluate(
        [OB("O1", "D01_CONCEPT_INTENT_SYN", ("Q05",))],
        effective_answers=answers,
        slot_constructs=SYNTHETIC_SLOT_CONSTRUCTS,
        slot_contexts={"Q05": "CURRENT_DIGEST"},
    )
    resolution = result.resolution("O1")
    assert resolution.status == OBJECTIVE_BRANCH_RESOLVED
    assert resolution.context_digest == "CURRENT_DIGEST"


# ---------------------------------------------------------------------------
# 16. D-2 (QA): the default construct_status must fail closed. An obligation
#     that does not explicitly opt in to APPROVED can never resolve.
# ---------------------------------------------------------------------------
def test_default_construct_status_is_fail_closed():
    obligation = ObjectiveObligation("O1", "D01_CONCEPT_INTENT", ("Q05",))
    assert obligation.construct_status != APPROVED
    result = evaluate(
        [obligation],
        effective_answers=full_answers(),
        slot_constructs={"Q05": "D01_CONCEPT_INTENT"},
    )
    assert result.resolution("O1").status == HOLD_RELEASE_OBJECTIVE_COVERAGE
    assert result.final_ready is False
