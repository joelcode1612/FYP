class Entity:
    pass
