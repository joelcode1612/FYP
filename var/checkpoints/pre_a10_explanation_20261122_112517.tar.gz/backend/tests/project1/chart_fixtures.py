"""Synthetic ``chart-spec/1`` fixtures; no fielding, no authority.

Every fixture here is a frozen, hand-authored payload that matches the shapes
``Ee01Service._read`` and ``Ee01Service._report_context`` return after
``plain()`` (datetimes stringified, ``Decimal`` stringified, ints preserved).
The Q05 wording and option codes are read from the frozen CUST03 contract so
the fixture cannot drift from the instrument it claims to describe.
"""
from __future__ import annotations

import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

from sitewise.domain.customer_questionnaire import digest as ee01_digest

_CONTRACT = (Path(__file__).resolve().parents[2] / 'src' / 'sitewise' / 'customer_contracts'
             / 'reference' / 'CUST_RECOVERY_20261027'
             / 'CUST03_CORRECTED_QUESTIONNAIRE_AND_ROUTING_CONTRACT.json')

CUTOFF = '2026-11-22T09:00:00+00:00'

Q05_COUNTS = {'DEF_NO': 12, 'PROB_NO': 9, 'UNSURE': 7, 'PROB_YES': 14, 'DEF_YES': 8}


def load_question(item_id: str = 'Q05') -> dict:
    contract = json.loads(_CONTRACT.read_text(encoding='utf-8'))
    for item in contract['items']:
        if item['id'] == item_id:
            return deepcopy(item)
    raise KeyError(item_id)


def snapshot(*, counts: dict[str, int] | None = None, v: int | None = None,
             s: int | None = None, status: str | None = None,
             scope: str = 'ISOLATED_TEST', origin: str = 'SYNTHETIC_TEST',
             cell_v: int | None = None, snapshot_id: str = 'snap-0001',
             fingerprint: str = 'fp-0001', question_id: str = 'Q05') -> dict:
    """Build a synthetic EE-01 diagnostic snapshot.

    ``counts`` maps option code to ``x``. ``V`` defaults to the sum of the
    substantive counts, which is the single-select invariant. The cell set is
    derived from the question's own substantive codes, so a fixture cannot carry
    a code the instrument does not declare.
    """
    question = load_question(question_id)
    substantive = list(question['substantive_codes'])
    counts = dict(Q05_COUNTS if counts is None else counts)
    # EE-01 emits one category cell per substantive code even when every count
    # is zero, so the fixture must too; an absent cell is a different fault.
    cells_source = {code: int(counts.get(code, 0)) for code in substantive}
    total = sum(cells_source.values())
    V = total if v is None else v
    S = (total + 3) if s is None else s
    Q = S + 2
    A = total
    if status is None:
        status = 'NOT_SHOWN' if S == 0 else ('NOT_ESTIMABLE' if V == 0 else 'WITHHELD_NOT_AUTHORIZED')
    cells = [{'code': code, 'x': x, 'v': V if cell_v is None else cell_v,
              'percentage': None, 'diagnostic_percentage': None, 'status': status}
             for code, x in cells_source.items()]
    # EE-01 derives the Q05 top-two cell as a category over two substantive codes.
    if question_id == 'Q05' and {'PROB_YES', 'DEF_YES'} <= set(cells_source):
        cells.append({'code': 'TOP_TWO_STATED_INTEREST',
                      'x': cells_source['PROB_YES'] + cells_source['DEF_YES'],
                      'v': V if cell_v is None else cell_v,
                      'percentage': None, 'diagnostic_percentage': None, 'status': status})
    return {
        'contract_version': 'ee01-diagnostic/1',
        'id': snapshot_id,
        'owner_user_id': 'user-0001',
        'assessment_id': 'assess-0001',
        'campaign_id': 'campaign-0001',
        'release_id': 'release-0001',
        'slot_id': f'{question_id}:s1' if question_id == 'Q10' else question_id,
        'question_version': f'{question_id.lower()}-v1',
        'cutoff': CUTOFF,
        'fingerprint': fingerprint,
        'rules_hash': 'rules-0001',
        'source_hash': 'source-0001',
        'scope': scope,
        'status': status,
        'q': Q, 's': S, 'a': A, 'v': V,
        'metadata_json': {
            'manifest_hash': 'manifest-0001',
            'instrument_version': 'concept-v1',
            'bank_version': 'bank-v1',
            'routing_version': 'routing-v1',
            'consent_version': 'consent-v1',
            'stimulus_hash': 'stimulus-0001',
            'qualification_versions': ['qual-v1'],
            'research_mode': 'DEVELOPER_PREVIEW' if origin == 'SYNTHETIC_TEST' else 'CUSTOMER_DEMAND_SURVEY',
            'rule': 'ACCEPTED_EFFECTIVE_DIAGNOSTIC',
            'authority': 'AUTHORITY_UNVERIFIED',
            'privacy_policy': 'WITHHOLD_ALL_FINDINGS',
            'selection': 'LATEST_ACCEPTED',
            'cutoff_basis': 'COMMITTED_BUILD_SNAPSHOT_WITH_EVENT_TIME_CUTOFF',
            'scientific_gaps': ['A_DEFINITION_UNRESOLVED', 'REVISION_POLICY_UNVERIFIED',
                                'MEASUREMENT_CLAIM_UNAUTHORIZED'],
            'origin': origin,
            'synthetic_run_id': 'run-0001',
            'consent_semantics': 'SIMULATED_NONHUMAN_NOT_INFORMED_CONSENT',
            'real_reportable': False,
            'diagnostic_qualification': 'TEST_ONLY_REPLAY_OF_FROZEN_FIXTURE_PREDICATES',
        },
        'counts_json': {**counts, 'not_shown': 0, 'excluded': 0},
        'cells': cells,
    }


def readback(snap: dict, *, gates: list[str] | None = None) -> dict:
    """Build the held readback exactly as ``_store_held_context`` writes it."""
    context = {
        'snapshot_id': snap['id'],
        'fingerprint': snap['fingerprint'],
        'assessment_id': snap['assessment_id'],
        'campaign_id': snap['campaign_id'],
        'source_hash': snap['source_hash'],
        'rules_hash': snap['rules_hash'],
        'authority': 'AUTHORITY_UNVERIFIED',
        'findings': [],
        'gates': gates or ['EXPLANATION_TEMPLATE_AUTHORITY_UNVERIFIED',
                           'A10_ADAPTER_UNVERIFIED', 'REPORT_ADMISSION_REQUIRED'],
    }
    if snap['metadata_json'].get('origin') == 'SYNTHETIC_TEST':
        context.update(origin='SYNTHETIC_TEST',
                       synthetic_run_id=snap['metadata_json']['synthetic_run_id'],
                       real_reportable=False)
        context['gates'] = [*context['gates'], 'SYNTHETIC_DATA_NOT_REPORTABLE']
    return {
        'contract_version': 'ee01-report-readback/1',
        'status': 'REPORT_FINDINGS_WITHHELD_NO_AUTHORIZED_SOURCE',
        'context_hash': ee01_digest(context),
        'context': context,
        'findings': [],
    }


def utc(value: str = CUTOFF) -> datetime:
    return datetime.fromisoformat(value).astimezone(timezone.utc)
