"""Offline HTTP tests for the governed BDJ objective proposal surface.

These run without a database. They exercise the real FastAPI router, the real
``BDJEngine.propose_objectives``, the real ``ModelRunner``, the real
``ObjectiveSimulationDisclosure`` and the real ``bdj-objective-proposal/1``
validators; only the persistence adapter, the attempt ledger and the source
projector are substituted, because those are proven against PostgreSQL by
``tools/phase2_gateBC_http_e2e_20261122.py``.

The DB-level harness is authoritative for:
  * the real ``objective_adapter`` SQL (persistence, decisions, admission);
  * the real ``PostgresAttemptLedger``;
  * owner-scoped RLS behaviour.

No test here treats an unexpected exception as a pass: every case asserts a
specific status code and refusal code.
"""
import copy
from types import SimpleNamespace
from uuid import uuid4

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient

from sitewise.api.v1 import project1_objective_proposals as api
from sitewise.api.v1 import project1_workflow as workflow
from sitewise.core.config import settings
from sitewise.project1.contracts import WorkflowHeld, digest
from sitewise.project1.objective_proposal import BoundObjectiveProposal
from sitewise.services.business_context_v1 import source_hash

REVISION = 11

DECLARATIONS = [
    {"item_key": "M2V1-01", "answer_revision_id": "rev-01-r11",
     "item_version_id": "item-01-v1", "answer_state": "ANSWERED",
     "value": "UNDECIDED"},
    {"item_key": "M2V1-02", "answer_revision_id": "rev-02-r11",
     "item_version_id": "item-02-v1", "answer_state": "ANSWERED",
     "value": "DINE_IN"},
    {"item_key": "M2V1-08", "answer_revision_id": "rev-08-r11",
     "item_version_id": "item-08-v1", "answer_state": "ANSWERED",
     "value": ["UNKNOWN"]},
    {"item_key": "M2V1-11", "answer_revision_id": "rev-11-r11",
     "item_version_id": "item-11-v1", "answer_state": "ANSWERED",
     "value": "UNSURE"},
]


class Contexts:
    """Stands in for PersistedBusinessContextService.retrieve."""

    def __init__(self, result):
        self.result = result
        self.calls = 0

    def retrieve(self, assessment_id, context_id, actor):
        self.calls += 1
        if self.result is None:
            from sitewise.core.exceptions import NotFoundError
            raise NotFoundError("Business context not found.")
        assert str(assessment_id) == str(self.result["assessment_id"])
        assert str(context_id) == str(self.result["context_id"])
        assert str(actor.user_id) == str(self.result["owner_id"])
        return copy.deepcopy(self.result)


def make_world():
    owner, assessment, confirmation, context = uuid4(), uuid4(), uuid4(), uuid4()
    packet = {
        "schema_version": "project1-m2-projection/1-candidate",
        "instrument_version": "M2V1-20261114-1",
        "assessment_id": str(assessment),
        "assessment_revision": REVISION,
        "confirmed": True,
        "confirmation": {"confirmation_id": str(confirmation),
                         "snapshot_digest": "d" * 64},
        "declarations": copy.deepcopy(DECLARATIONS),
    }
    # verify_projection() recomputes the fingerprint, so it must be real.
    packet["source_fingerprint"] = digest(packet)

    context_packet = {
        "schema_version": "business-context-package/1.1",
        "context_version": "BCB-V1-TEST",
        "identity": {"assessment_id": str(assessment), "owner_id": str(owner)},
        "confirmation": {"id": str(confirmation), "revision": REVISION,
                         "digest": "d" * 64, "status": "CURRENT_CONFIRMED"},
        "permissions": {"qj_execution": False, "qg_execution": False},
        "m2_answers": copy.deepcopy(DECLARATIONS),
        "business_description": "Synthetic test description.",
    }
    context_packet["packet_hash"] = source_hash(context_packet)
    stored = {
        "contract_version": "persisted-business-context/1",
        "context_id": str(context),
        "assessment_id": str(assessment),
        "confirmation_id": str(confirmation),
        "assessment_revision": REVISION,
        "lifecycle_status": "PERSISTED",
        "qj_execution_authorized": False,
        "qg_execution_authorized": False,
        "packet": context_packet,
        "owner_id": str(owner),
    }
    return SimpleNamespace(owner=owner, assessment=assessment,
                           confirmation=confirmation, context=context,
                           packet=packet, context_packet=context_packet,
                           stored_context=stored)


class LedgerState:
    def __init__(self):
        self.reserves = []
        self.receipt = None
        self.run_id = uuid4()


class FakeAttemptLedger:
    """Mirrors the reserve-before-dispatch contract of PostgresAttemptLedger."""

    def __init__(self, state):
        self.state = state

    def reserve(self, stage, prompt_version, prompt_hash, request_hash, *,
                attempt_slot=1):
        if stage in [r["stage"] for r in self.state.reserves]:
            raise WorkflowHeld("MODEL_STAGE_ALREADY_RESERVED")
        self.state.reserves.append({"stage": stage,
                                    "prompt_version": prompt_version,
                                    "prompt_hash": prompt_hash,
                                    "request_hash": request_hash})
        return len(self.state.reserves)

    def finish(self, attempt, outcome, output_digest):
        if outcome not in {"returned", "rejected", "unknown_outcome"}:
            raise WorkflowHeld("MODEL_RECEIPT_OUTCOME_INVALID")
        self.state.receipt = (attempt, outcome, output_digest)


class FakeStore:
    """Mirrors objective_adapter's contract without SQL."""

    def __init__(self, world):
        self.world = world
        self.rows = {}
        self.decisions = {}
        self.persisted = []
        self.fail_persist = False

    def persist(self, engine, bound, *, owner_user_id, evaluation_id, assessment_id,
                confirmation_revision, confirmation_id, source_fingerprint,
                prompt_version, execution_mode="SIMULATED", model_provider=None,
                model_requested=None, model_returned=None):
        if self.fail_persist:
            raise WorkflowHeld("PROPOSAL_DB_TARGET_REFUSED")
        assert isinstance(bound, BoundObjectiveProposal)
        self.persisted.append({
            "contract_version": bound.contract_version,
            "context_id": bound.context_id,
            "context_packet_hash": bound.context_packet_hash,
            "confirmation_id": bound.confirmation_id,
            "confirmation_digest": bound.confirmation_digest,
            "execution_mode": execution_mode,
            "model_provider": model_provider,
            "source_fingerprint": source_fingerprint,
            "prompt_version": prompt_version,
            "recommendations": len(bound.proposals),
        })
        from sitewise.project1.objective_adapter import proposal_identity
        out = []
        for rec in bound.proposals:
            pid = str(proposal_identity(
                assessment_id=assessment_id,
                confirmation_revision=confirmation_revision,
                confirmation_id=confirmation_id,
                context_packet_hash=bound.context_packet_hash,
                contract_version=bound.contract_version,
                prompt_version=prompt_version, recommendation=rec))
            created = pid not in self.rows
            self.rows.setdefault(pid, {
                "proposal_id": pid, "evaluation_id": str(evaluation_id),
                "assessment_id": str(assessment_id),
                "confirmation_id": str(confirmation_id),
                "confirmation_revision": int(confirmation_revision),
                "source_fingerprint": source_fingerprint,
                "context_id": bound.context_id,
                "context_packet_hash": bound.context_packet_hash,
                "recommendation_status": rec.recommendation_status,
                "problem_type": rec.problem_type, "problem": rec.problem,
                "research_objective": rec.research_objective,
                "reason": rec.reason,
                "source_refs": [r.model_dump() for r in rec.source_refs],
                "contract_version": bound.contract_version,
                "prompt_version": prompt_version,
                "execution_mode": execution_mode,
                "validation_status": "VALID",
                "review_state": "CANDIDATE",
                "owner_user_id": str(owner_user_id),
            })
            out.append({"proposal_id": pid, "created": created})
        return out

    def read(self, engine, proposal_id, owner_user_id):
        row = self.rows.get(str(proposal_id))
        if row is None or row["owner_user_id"] != str(owner_user_id):
            return None
        return copy.deepcopy(row)

    def read_for_assessment(self, engine, assessment_id, owner_user_id,
                            confirmation_revision, limit=50):
        return [copy.deepcopy(r) for r in self.rows.values()
                if r["assessment_id"] == str(assessment_id)
                and r["owner_user_id"] == str(owner_user_id)
                and r["confirmation_revision"] == int(confirmation_revision)]

    def decide(self, engine, proposal_id, *, actor_id, decision,
               source_fingerprint, context_packet_hash, note=None):
        row = self.rows.get(str(proposal_id))
        if row is None:
            raise WorkflowHeld("PROPOSAL_NOT_FOUND")
        if row["owner_user_id"] != str(actor_id):
            raise WorkflowHeld("PROPOSAL_DECISION_FORBIDDEN")
        if (row["source_fingerprint"] != source_fingerprint
                or row["context_packet_hash"] != context_packet_hash):
            raise WorkflowHeld("PROPOSAL_DECISION_STALE")
        existing = self.decisions.get(str(proposal_id))
        if existing is not None:
            if existing["decision"] == decision:
                return {"decision_id": existing["decision_id"],
                        "decision": decision, "created": False}
            raise WorkflowHeld("PROPOSAL_ALREADY_DECIDED")
        decision_id = str(uuid4())
        self.decisions[str(proposal_id)] = {
            "decision_id": decision_id, "decision": decision,
            "decided_by": str(actor_id), "decided_at": "2026-11-22T00:00:00Z",
            "source_fingerprint": source_fingerprint,
            "context_packet_hash": context_packet_hash, "note": note,
        }
        row["review_state"] = decision
        return {"decision_id": decision_id, "decision": decision, "created": True}

    def read_decision(self, engine, proposal_id, owner_user_id):
        row = self.rows.get(str(proposal_id))
        if row is None or row["owner_user_id"] != str(owner_user_id):
            return None
        return copy.deepcopy(self.decisions.get(str(proposal_id)))

    def admission_status(self, engine, proposal_id, *, source_fingerprint,
                         actor_id):
        # Mirrors objective_adapter.admission_status. The real implementation is
        # proven against PostgreSQL by the DB harness; this fake keeps the HTTP
        # contract under test here.
        row = self.rows.get(str(proposal_id))
        base = {"qj_execution": False, "qg_execution": False,
                "fielding_authorized": False, "uncertainty_link": None}
        if row is None:
            return {**base, "admission_state": "NOT_ADMISSIBLE",
                    "admission_reason": "PROPOSAL_NOT_FOUND",
                    "pending_requirement": None}
        if row["source_fingerprint"] != source_fingerprint:
            return {**base, "admission_state": "NOT_ADMISSIBLE",
                    "admission_reason": "PROPOSAL_SOURCE_STALE",
                    "pending_requirement": None}
        decision = (self.decisions.get(str(proposal_id)) or {}).get("decision")
        if decision != "APPROVED":
            return {**base, "admission_state": "NOT_ADMISSIBLE",
                    "admission_reason": "PROPOSAL_NOT_APPROVED",
                    "pending_requirement": None}
        return {**base, "admission_state": "HELD",
                "admission_reason": "M2_UNCERTAINTY_LINK_REQUIRED",
                "pending_requirement": "Post-confirmation finding authority is "
                                       "not adopted."}


@pytest.fixture(autouse=True)
def enabled_contract(monkeypatch):
    monkeypatch.setattr(settings, "project1_bdj_contract", "objective")
    monkeypatch.setattr(settings, "m2_bcb_persistence_enabled", True)


def build(world, *, source_packet=None, context=None, store=None,
          ledger_state=None, auth_error=None, monkeypatch=None):
    from sitewise.project1 import ledger as ledger_module
    from sitewise.project1 import objective_adapter
    from sitewise.project1 import runs as runs_module

    store = store or FakeStore(world)
    ledger_state = ledger_state or LedgerState()
    contexts = context or Contexts(world.stored_context)

    def source_reader(session, user, assessment_id, revision):
        from sitewise.core.exceptions import ConflictError
        if (str(user.user_id) != str(world.owner)
                or str(assessment_id) != str(world.assessment)
                or revision != REVISION):
            raise ConflictError("Confirm the current M2 declarations.")
        return copy.deepcopy(source_packet or world.packet)

    monkeypatch.setattr(objective_adapter, "persist", store.persist)
    monkeypatch.setattr(objective_adapter, "read", store.read)
    monkeypatch.setattr(objective_adapter, "read_for_assessment",
                        store.read_for_assessment)
    monkeypatch.setattr(objective_adapter, "decide", store.decide)
    monkeypatch.setattr(objective_adapter, "read_decision", store.read_decision)
    monkeypatch.setattr(objective_adapter, "admission_status",
                        store.admission_status)
    monkeypatch.setattr(ledger_module, "PostgresAttemptLedger",
                        lambda *a, **k: FakeAttemptLedger(ledger_state))
    monkeypatch.setattr(runs_module, "ensure_objective_run",
                        lambda *a, **k: ledger_state.run_id)
    monkeypatch.setattr(runs_module, "attempt_count",
                        lambda *a, **k: len(ledger_state.reserves))
    monkeypatch.setattr(runs_module, "latest_receipt",
                        lambda *a, **k: ledger_state.receipt)

    app = FastAPI()
    app.include_router(workflow.router, prefix="/project1-workflow")
    app.dependency_overrides[workflow.configuration_gate] = lambda: None
    if auth_error is None:
        app.dependency_overrides[api.require_entrepreneur] = lambda: SimpleNamespace(
            user_id=world.owner, role="entrepreneur")
    else:
        def refuse():
            raise HTTPException(401, detail={"code": "unauthorized"})
        app.dependency_overrides[api.require_entrepreneur] = refuse
    app.dependency_overrides[api.get_objective_source_db] = lambda: object()
    app.dependency_overrides[api.get_workflow_packet_source] = lambda: source_reader
    app.dependency_overrides[api.get_objective_context_service] = lambda: contexts
    app.dependency_overrides[api.get_authorized_proposal_storage_engine] = lambda: object()
    app.dependency_overrides[api.get_authorized_ledger_engine] = lambda: object()
    return TestClient(app), store, ledger_state, contexts


def endpoint(world):
    return f"/project1-workflow/assessments/{world.assessment}/objective-proposals"


def query(world):
    return {"expected_revision": REVISION, "context_id": str(world.context)}


# ---------------------------------------------------------------------------
# 1-2. Registration and schema
# ---------------------------------------------------------------------------
def test_router_registers_the_governed_paths():
    paths = {(r.path, method) for r in api.router.routes
             for method in getattr(r, "methods", set())}
    assert ("/assessments/{assessment_id}/objective-proposals/evaluate", "POST") in paths
    assert ("/assessments/{assessment_id}/objective-proposals", "GET") in paths
    assert ("/assessments/{assessment_id}/objective-proposals", "POST") in paths
    assert ("/assessments/{assessment_id}/objective-proposals/{proposal_id}", "GET") in paths
    assert ("/assessments/{assessment_id}/objective-proposals/{proposal_id}/decision",
            "POST") in paths
    assert ("/assessments/{assessment_id}/objective-proposals/{proposal_id}/decision",
            "GET") in paths


def test_openapi_documents_the_request_contract():
    app = FastAPI()
    app.include_router(api.router)
    paths = app.openapi()["paths"]
    evaluate = paths["/assessments/{assessment_id}/objective-proposals/evaluate"]["post"]
    assert evaluate["requestBody"]["content"]["application/json"]["schema"]
    decision = paths[
        "/assessments/{assessment_id}/objective-proposals/{proposal_id}/decision"]["post"]
    assert decision["requestBody"]["content"]["application/json"]["schema"]


# ---------------------------------------------------------------------------
# 3. Strict request validation
# ---------------------------------------------------------------------------
def test_request_validation_is_strict(monkeypatch):
    world = make_world()
    client, store, _, _ = build(world, monkeypatch=monkeypatch)
    body = query(world)

    extra = client.post(endpoint(world) + "/evaluate",
                        json={**body, "owner_user_id": str(world.owner)})
    assert extra.status_code == 422
    assert store.persisted == []

    missing = client.post(endpoint(world) + "/evaluate",
                          json={"expected_revision": REVISION})
    assert missing.status_code == 422

    negative = client.post(endpoint(world) + "/evaluate",
                           json={**body, "expected_revision": -1})
    assert negative.status_code == 422

    bad_decision = client.post(
        endpoint(world) + f"/{uuid4()}/decision",
        json={**body, "decision": "MAYBE"})
    assert bad_decision.status_code == 422


# ---------------------------------------------------------------------------
# 4. Authenticated owner execution
# ---------------------------------------------------------------------------
def test_owner_execution_persists_candidate_proposals(monkeypatch):
    world = make_world()
    client, store, ledger_state, contexts = build(world, monkeypatch=monkeypatch)
    response = client.post(endpoint(world) + "/evaluate", json=query(world))

    assert response.status_code == 200, response.text
    body = response.json()
    assert body["outcome"] == "reviewed"
    assert body["proposal_count"] == 3          # M2V1-01, M2V1-08, M2V1-11
    assert body["context_packet_hash"] == world.context_packet["packet_hash"]
    assert body["source_fingerprint"] == world.packet["source_fingerprint"]
    assert body["finding_authority"] == "CANDIDATE_ONLY"
    assert body["qj_execution"] is False and body["qg_execution"] is False
    assert all(p["created"] is True for p in body["proposals"])
    assert all(p["review_state"] == "CANDIDATE" for p in body["proposals"])

    execution = body["execution"]
    assert execution["execution_mode"] == "SIMULATED"
    assert execution["dispatched"] is False
    assert execution["receipt_outcome"] == "returned"
    assert execution["reused"] is False

    assert len(store.persisted) == 1
    written = store.persisted[0]
    assert written["execution_mode"] == "SIMULATED"
    assert written["model_provider"] == "simulated-objective-v1"
    assert written["context_packet_hash"] == world.context_packet["packet_hash"]
    assert written["source_fingerprint"] == world.packet["source_fingerprint"]
    assert written["recommendations"] == 3

    # The ledger records the governed stage, not the prompt name.
    assert ledger_state.reserves[0]["stage"] == "BDJ"
    assert ledger_state.receipt[1] == "returned"
    assert contexts.calls == 1


def test_readback_returns_persisted_rows(monkeypatch):
    world = make_world()
    client, _, _, _ = build(world, monkeypatch=monkeypatch)
    created = client.post(endpoint(world) + "/evaluate", json=query(world)).json()

    listed = client.get(endpoint(world), params=query(world))
    assert listed.status_code == 200
    assert {p["proposal_id"] for p in listed.json()["proposals"]} == {
        p["proposal_id"] for p in created["proposals"]}

    single = client.get(
        endpoint(world) + f"/{created['proposals'][0]['proposal_id']}",
        params=query(world))
    assert single.status_code == 200
    payload = single.json()
    assert payload["execution_mode"] == "SIMULATED"
    assert payload["recommendation"]["recommendation_status"] == "MOST_SUGGESTED"
    assert "owner_user_id" not in payload


def test_duplicate_evaluation_never_dispatches_twice(monkeypatch):
    world = make_world()
    client, store, ledger_state, _ = build(world, monkeypatch=monkeypatch)
    first = client.post(endpoint(world) + "/evaluate", json=query(world)).json()
    second = client.post(endpoint(world) + "/evaluate", json=query(world))

    assert second.status_code == 200, second.text
    assert second.json()["execution"]["reused"] is True
    assert {p["proposal_id"] for p in second.json()["proposals"]} == {
        p["proposal_id"] for p in first["proposals"]}
    assert len(store.persisted) == 1
    assert len(ledger_state.reserves) == 1


# ---------------------------------------------------------------------------
# 5. Unauthorized refusal
# ---------------------------------------------------------------------------
def test_unauthenticated_execution_is_refused(monkeypatch):
    world = make_world()
    client, store, ledger_state, contexts = build(
        world, auth_error="denied", monkeypatch=monkeypatch)
    response = client.post(endpoint(world) + "/evaluate", json=query(world))

    assert response.status_code == 401
    assert store.persisted == []
    assert ledger_state.reserves == []
    assert contexts.calls == 0


# ---------------------------------------------------------------------------
# 6-7. Simulator-only enforcement
# ---------------------------------------------------------------------------
def test_simulator_disclosure_refuses_anything_but_the_simulator():
    from sitewise.project1.objective_simulation import (
        SIMULATOR_ENDPOINT, SIMULATOR_MODEL, ObjectiveSimulationDisclosure)
    from sitewise.project1.provider import ENDPOINT, MODEL

    world = make_world()
    gate = ObjectiveSimulationDisclosure(
        assessment_id=world.assessment, revision=REVISION,
        confirmation_id=world.confirmation,
        source_fingerprint=world.packet["source_fingerprint"],
        context_packet_hash=world.context_packet["packet_hash"])

    gate.require_current("BDJ", world.packet, SIMULATOR_ENDPOINT, SIMULATOR_MODEL)

    with pytest.raises(WorkflowHeld) as stage:
        gate.require_current("QJ", world.packet, SIMULATOR_ENDPOINT, SIMULATOR_MODEL)
    assert str(stage.value) == "DISCLOSURE_STAGE_NOT_AUTHORIZED"

    with pytest.raises(WorkflowHeld) as model:
        gate.require_current("BDJ", world.packet, ENDPOINT, MODEL)
    assert str(model.value) == "DISCLOSURE_MODEL_MISMATCH"

    with pytest.raises(WorkflowHeld) as endpoint_error:
        gate.require_current("BDJ", world.packet, "https://example.invalid",
                             SIMULATOR_MODEL)
    assert str(endpoint_error.value) == "DISCLOSURE_ENDPOINT_MISMATCH"

    with pytest.raises(WorkflowHeld) as source:
        gate.require_current("BDJ", {**world.packet, "source_fingerprint": "e" * 64},
                             SIMULATOR_ENDPOINT, SIMULATOR_MODEL)
    assert str(source.value) == "DISCLOSURE_SOURCE_MISMATCH"


def test_simulated_provider_performs_no_io():
    from sitewise.project1.objective_simulation import SimulatedObjectiveProvider

    world = make_world()
    provider = SimulatedObjectiveProvider(world.packet)
    assert not hasattr(provider, "transport")
    assert provider.model == "simulated-objective-v1"
    output = provider.complete([], type(
        "Schema", (), {"model_validate": staticmethod(lambda raw: raw)}))
    assert output["contract_version"] == "bdj-objective-proposal/1"
    assert provider.last_execution["dispatched"] is False
    assert provider.last_execution["execution_mode"] == "SIMULATED"


# ---------------------------------------------------------------------------
# 8. Invalid source / context
# ---------------------------------------------------------------------------
def test_stale_source_is_refused_before_any_execution(monkeypatch):
    world = make_world()
    stale = copy.deepcopy(world.packet)
    stale["confirmed"] = False
    client, store, ledger_state, contexts = build(
        world, source_packet=stale, monkeypatch=monkeypatch)
    response = client.post(endpoint(world) + "/evaluate", json=query(world))

    assert response.status_code == 409
    assert response.json()["detail"]["code"] == "BDJ_OBJECTIVE_SOURCE_NOT_CURRENT"
    assert contexts.calls == 0
    assert ledger_state.reserves == []
    assert store.persisted == []


def test_context_from_another_owner_is_refused(monkeypatch):
    world = make_world()
    foreign = copy.deepcopy(world.stored_context)
    foreign["packet"]["identity"]["owner_id"] = str(uuid4())
    foreign["packet"]["packet_hash"] = source_hash(
        {k: v for k, v in foreign["packet"].items() if k != "packet_hash"})
    client, store, _, _ = build(
        world, context=Contexts(foreign), monkeypatch=monkeypatch)
    response = client.post(endpoint(world) + "/evaluate", json=query(world))

    assert response.status_code == 409
    assert response.json()["detail"]["code"] == "BDJ_OBJECTIVE_CONTEXT_SOURCE_MISMATCH"
    assert store.persisted == []


def test_unknown_context_is_not_found(monkeypatch):
    world = make_world()
    client, _, _, _ = build(world, context=Contexts(None), monkeypatch=monkeypatch)
    response = client.get(endpoint(world), params=query(world))
    assert response.status_code == 404
    assert response.json()["detail"]["code"] == "BDJ_OBJECTIVE_CONTEXT_NOT_FOUND"


def test_context_packet_hash_mismatch_is_refused(monkeypatch):
    world = make_world()
    tampered = copy.deepcopy(world.stored_context)
    tampered["packet"]["packet_hash"] = "f" * 64
    client, store, _, _ = build(
        world, context=Contexts(tampered), monkeypatch=monkeypatch)
    response = client.post(endpoint(world) + "/evaluate", json=query(world))
    assert response.status_code == 409
    assert response.json()["detail"]["code"] == "BDJ_OBJECTIVE_CONTEXT_SOURCE_MISMATCH"
    assert store.persisted == []


# ---------------------------------------------------------------------------
# 9. Invalid model output
# ---------------------------------------------------------------------------
def test_invalid_model_output_is_rejected(monkeypatch):
    from sitewise.project1 import objective_simulation

    class BrokenProvider(objective_simulation.SimulatedObjectiveProvider):
        def complete(self, messages, output_type):
            # SUGGESTED may not carry a problem: contract violation.
            return {"contract_version": "bdj-objective-proposal/1",
                    "recommendations": [{
                        "recommendation_status": "SUGGESTED",
                        "problem_type": "EXPLORATORY_RESEARCH_NEED",
                        "problem": "An invented problem.",
                        "research_objective": "To explore the invented problem.",
                        "source_refs": [], "reason": "Synthetic.",
                        "authority": "CANDIDATE_ONLY"}]}

    monkeypatch.setattr(objective_simulation, "SimulatedObjectiveProvider",
                        BrokenProvider)
    world = make_world()
    client, store, ledger_state, _ = build(world, monkeypatch=monkeypatch)
    response = client.post(endpoint(world) + "/evaluate", json=query(world))

    assert response.status_code == 422, response.text
    detail = response.json()["detail"]
    assert detail["code"] == "BDJ_OBJECTIVE_CANDIDATE_REJECTED"
    assert detail["reason"] == "BDJ_OBJECTIVE_PROBLEM_NOT_ALLOWED"
    assert store.persisted == []
    assert ledger_state.receipt[1] == "returned"   # the attempt was consumed


# ---------------------------------------------------------------------------
# 10. Genuine execution failure
# ---------------------------------------------------------------------------
def test_provider_failure_is_a_hold_not_a_success(monkeypatch):
    from sitewise.project1 import objective_simulation

    class FailingProvider(objective_simulation.SimulatedObjectiveProvider):
        def complete(self, messages, output_type):
            raise WorkflowHeld("PROVIDER_NOT_CONFIGURED")

    monkeypatch.setattr(objective_simulation, "SimulatedObjectiveProvider",
                        FailingProvider)
    world = make_world()
    client, store, ledger_state, _ = build(world, monkeypatch=monkeypatch)
    response = client.post(endpoint(world) + "/evaluate", json=query(world))

    assert response.status_code == 503, response.text
    detail = response.json()["detail"]
    assert detail["code"] == "BDJ_OBJECTIVE_EXECUTION_HELD"
    assert detail["reason"] == "PROVIDER_NOT_CONFIGURED"
    assert store.persisted == []
    assert ledger_state.receipt[1] == "rejected"


def test_persistence_failure_never_returns_proposals(monkeypatch):
    world = make_world()
    store = FakeStore(world)
    store.fail_persist = True
    client, _, _, _ = build(world, store=store, monkeypatch=monkeypatch)
    response = client.post(endpoint(world) + "/evaluate", json=query(world))

    assert response.status_code == 503, response.text
    assert response.json()["detail"]["code"] == "PROPOSAL_DB_TARGET_REFUSED"
    assert "proposals" not in response.json()


# ---------------------------------------------------------------------------
# Decisions and admission separation
# ---------------------------------------------------------------------------
def test_approval_is_recorded_but_admission_stays_held(monkeypatch):
    world = make_world()
    client, _, _, _ = build(world, monkeypatch=monkeypatch)
    created = client.post(endpoint(world) + "/evaluate", json=query(world)).json()
    proposal_id = created["proposals"][0]["proposal_id"]

    approved = client.post(
        endpoint(world) + f"/{proposal_id}/decision",
        json={**query(world), "decision": "APPROVED", "note": "ok"})
    assert approved.status_code == 200, approved.text
    body = approved.json()
    assert body["decision"] == "APPROVED"
    assert body["decision_created"] is True
    assert body["review_state"] == "APPROVED"
    assert body["admission"]["admission_state"] == "HELD"
    assert body["admission"]["admission_reason"] == "M2_UNCERTAINTY_LINK_REQUIRED"
    assert body["admission"]["uncertainty_link"] is None
    assert body["admission"]["qj_execution"] is False
    assert body["admission"]["qg_execution"] is False
    assert body["admission"]["fielding_authorized"] is False
    assert body["qj_execution"] is False and body["qg_execution"] is False

    readback = client.get(endpoint(world) + f"/{proposal_id}/decision",
                          params=query(world))
    assert readback.status_code == 200
    assert readback.json()["decision_id"] == body["decision_id"]


def test_rejected_proposal_is_not_admissible(monkeypatch):
    world = make_world()
    client, _, _, _ = build(world, monkeypatch=monkeypatch)
    created = client.post(endpoint(world) + "/evaluate", json=query(world)).json()
    proposal_id = created["proposals"][1]["proposal_id"]

    rejected = client.post(
        endpoint(world) + f"/{proposal_id}/decision",
        json={**query(world), "decision": "REJECTED"})
    assert rejected.status_code == 200, rejected.text
    body = rejected.json()
    assert body["review_state"] == "REJECTED"
    assert body["admission"]["admission_state"] == "NOT_ADMISSIBLE"
    assert body["admission"]["admission_reason"] == "PROPOSAL_NOT_APPROVED"


def test_pending_proposal_has_no_decision(monkeypatch):
    world = make_world()
    client, _, _, _ = build(world, monkeypatch=monkeypatch)
    created = client.post(endpoint(world) + "/evaluate", json=query(world)).json()
    proposal_id = created["proposals"][2]["proposal_id"]

    response = client.get(endpoint(world) + f"/{proposal_id}/decision",
                          params=query(world))
    assert response.status_code == 404
    assert response.json()["detail"]["code"] == "BDJ_OBJECTIVE_DECISION_NOT_FOUND"


def test_conflicting_decision_is_refused(monkeypatch):
    world = make_world()
    client, _, _, _ = build(world, monkeypatch=monkeypatch)
    created = client.post(endpoint(world) + "/evaluate", json=query(world)).json()
    proposal_id = created["proposals"][0]["proposal_id"]

    first = client.post(endpoint(world) + f"/{proposal_id}/decision",
                        json={**query(world), "decision": "APPROVED"})
    assert first.status_code == 200

    repeat = client.post(endpoint(world) + f"/{proposal_id}/decision",
                         json={**query(world), "decision": "APPROVED"})
    assert repeat.status_code == 200
    assert repeat.json()["decision_created"] is False
    assert repeat.json()["decision_id"] == first.json()["decision_id"]

    conflict = client.post(endpoint(world) + f"/{proposal_id}/decision",
                           json={**query(world), "decision": "REJECTED"})
    assert conflict.status_code == 409
    assert conflict.json()["detail"]["code"] == "BDJ_OBJECTIVE_ALREADY_DECIDED"


def test_decision_on_stale_source_is_refused(monkeypatch):
    world = make_world()
    client, _, _, _ = build(world, monkeypatch=monkeypatch)
    created = client.post(endpoint(world) + "/evaluate", json=query(world)).json()
    proposal_id = created["proposals"][0]["proposal_id"]

    from sitewise.project1 import objective_adapter

    def stale(*args, **kwargs):
        raise WorkflowHeld("PROPOSAL_DECISION_STALE")

    monkeypatch.setattr(objective_adapter, "decide", stale)
    response = client.post(endpoint(world) + f"/{proposal_id}/decision",
                           json={**query(world), "decision": "APPROVED"})
    assert response.status_code == 409
    assert response.json()["detail"]["code"] == "BDJ_OBJECTIVE_PROPOSAL_STALE"


def test_unknown_proposal_decision_is_not_found(monkeypatch):
    world = make_world()
    client, _, _, _ = build(world, monkeypatch=monkeypatch)
    response = client.post(endpoint(world) + f"/{uuid4()}/decision",
                           json={**query(world), "decision": "APPROVED"})
    assert response.status_code == 404
    assert response.json()["detail"]["code"] == "BDJ_OBJECTIVE_PROPOSAL_NOT_FOUND"


# ---------------------------------------------------------------------------
# Storage / ledger target guards
# ---------------------------------------------------------------------------
def test_storage_guard_refuses_the_protected_databases():
    from sqlalchemy.engine import URL
    for database, port in (("Dss", 5432), ("Final_Location_Analysis", 5432),
                           ("project1_workflow_tests", 5432)):
        engine = SimpleNamespace(url=URL.create(
            "postgresql+psycopg2", username="postgres", host="127.0.0.1",
            port=port, database=database))
        with pytest.raises(HTTPException) as caught:
            api.assert_proposal_storage_target(engine)
        assert caught.value.status_code == 503
        assert caught.value.detail["code"] == "PROPOSAL_DB_TARGET_REFUSED"


def test_ledger_guard_refuses_the_protected_databases():
    from sqlalchemy.engine import URL
    engine = SimpleNamespace(url=URL.create(
        "postgresql+psycopg2", username="p1ai_engine", host="127.0.0.1",
        port=5432, database="Dss"))
    with pytest.raises(HTTPException) as caught:
        api.assert_ledger_target(engine)
    assert caught.value.status_code == 503
    assert caught.value.detail["code"] == "LEDGER_DB_TARGET_REFUSED"
