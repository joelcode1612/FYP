"""BDJ objective admission — the post-confirmation finding-authority record.

The problem this solves
-----------------------
``m2-confirmation/3`` is declaration-only. Its snapshot pins
``unresolved_candidate_findings = []`` and ``finding_decision_event_refs = {}``,
and ``pins_match()`` rejects a v3 snapshot carrying findings or a
``bdj_evaluation_id``. That is deliberate: confirming declarations must not
confirm model findings.

But ``confirm_objective(origin='BDJ')`` refuses a v3 snapshot with
``M2_UNCERTAINTY_LINK_REQUIRED`` because it requires exactly that finding link.
So the gate is not a bug in one function — it is the visible edge of a record
that the v3 contract removed and never replaced.

What is missing is not more provenance. ``source_refs`` already prove which
answer, revision and item version a proposal cites, and the validator checks
they resolve inside the packet and belong to one item. What is missing is an
*owner decision*: a record that a named person, at a named confirmation, decided
that this particular gap is worth researching. Provenance is not authority.

This module adds that record. It is deliberately NOT wired into the production
router; see ``ADOPTION_STATUS``. Nothing here authorises QJ or QG.
"""
from __future__ import annotations

import hashlib
import json
import uuid

from sqlalchemy import text

from sitewise.project1.contracts import WorkflowHeld

#: Not yet wired into ``project1_objective_proposals``. The routes keep reporting
#: ``HELD`` until a separate adoption decision is recorded, so this module cannot
#: authorise anything by being imported.
ADOPTION_STATUS = 'PROPOSED_NOT_WIRED'

#: The single decision vocabulary, matching public.m2_finding_reviews.
WORTH_RESEARCHING = 'WORTH_RESEARCHING'

_HASH_FIELDS = ('proposal_id', 'assessment_id', 'confirmation_id',
                'confirmation_revision', 'source_fingerprint',
                'recommendation_status', 'problem_type', 'problem',
                'research_objective', 'reason', 'source_refs')


def proposal_hash(row: dict) -> str:
    """SHA-256 over the admission-relevant content of a proposal row.

    Canonicalised so the writer and every later verifier agree: sorted keys,
    compact separators, no NaN, UTF-8. ``source_refs`` may arrive as a JSON
    string or a list depending on the driver; both canonicalise to the same
    bytes.
    """
    refs = row.get('source_refs')
    if isinstance(refs, (str, bytes)):
        refs = json.loads(refs)
    body = {key: row.get(key) for key in _HASH_FIELDS}
    body['source_refs'] = refs if refs is not None else []
    body['confirmation_revision'] = int(body['confirmation_revision'])
    for key in ('proposal_id', 'assessment_id', 'confirmation_id'):
        body[key] = str(body[key])
    return hashlib.sha256(json.dumps(
        body, sort_keys=True, separators=(',', ':'),
        ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()


def _bind_actor(conn, actor_id):
    conn.execute(text("SELECT set_config('project1.actor_id', :a, true)"),
                 {'a': str(actor_id)})


def _load_proposal(conn, proposal_id) -> dict | None:
    row = conn.execute(text("""
        SELECT p.proposal_id, p.assessment_id, p.confirmation_id,
               p.confirmation_revision, p.source_fingerprint,
               p.recommendation_status, p.problem_type, p.problem,
               p.research_objective, p.reason, p.source_refs,
               p.owner_user_id, p.review_state, d.decision
        FROM public.m2_bdj_objective_proposals p
        LEFT JOIN public.m2_bdj_objective_decisions d USING (proposal_id)
        WHERE p.proposal_id = :pid
    """), {'pid': str(proposal_id)}).mappings().one_or_none()
    return dict(row) if row else None


def record_admission(engine, proposal_id, *, actor_id, request_id,
                     source_fingerprint=None) -> dict:
    """Append one owner admission for an APPROVED, source-current proposal.

    Refusals are deliberate and each has its own code so a caller can tell
    "you have not approved this yet" from "your approval went stale" from
    "this is not your proposal".
    """
    if actor_id is None:
        raise WorkflowHeld('PROPOSAL_OWNER_REQUIRED')
    with engine.begin() as conn:
        _bind_actor(conn, actor_id)
        row = _load_proposal(conn, proposal_id)
        if row is None:
            # RLS makes a foreign owner's row indistinguishable from a missing
            # one. That is the intended behaviour: no existence oracle.
            raise WorkflowHeld('PROPOSAL_NOT_FOUND')
        if row['decision'] != 'APPROVED':
            raise WorkflowHeld('PROPOSAL_NOT_APPROVED')
        if (source_fingerprint is not None
                and row['source_fingerprint'] != source_fingerprint):
            raise WorkflowHeld('PROPOSAL_SOURCE_STALE')

        existing = conn.execute(text("""
            SELECT admission_id, decision, proposal_hash, created_at
            FROM public.m2_bdj_objective_admissions
            WHERE proposal_id = :pid
        """), {'pid': str(proposal_id)}).mappings().one_or_none()
        if existing is not None:
            # Idempotent by proposal: a repeat is reported, never duplicated.
            return {'admission_id': str(existing['admission_id']),
                    'decision': existing['decision'], 'created': False,
                    'proposal_hash': existing['proposal_hash'],
                    'created_at': existing['created_at']}

        admission_id = uuid.uuid4()
        digest = proposal_hash(row)
        conn.execute(text("""
            INSERT INTO public.m2_bdj_objective_admissions (
                admission_id, proposal_id, assessment_id, confirmation_id,
                confirmation_revision, source_fingerprint, context_packet_hash,
                actor_user_id, decision, proposal_hash, request_id)
            VALUES (
                :aid, :pid, :assessment, :confirmation, :revision, :fp, :ctx,
                :actor, :decision, :hash, :request)
        """), {'aid': str(admission_id), 'pid': str(proposal_id),
               'assessment': str(row['assessment_id']),
               'confirmation': str(row['confirmation_id']),
               'revision': row['confirmation_revision'],
               'fp': row['source_fingerprint'],
               'ctx': _context_hash(conn, row),
               'actor': str(actor_id), 'decision': WORTH_RESEARCHING,
               'hash': digest, 'request': str(request_id)})
        return {'admission_id': str(admission_id), 'decision': WORTH_RESEARCHING,
                'created': True, 'proposal_hash': digest, 'created_at': None}


def _context_hash(conn, row) -> str:
    """The context packet hash the proposal was produced against."""
    value = conn.execute(text("""
        SELECT context_packet_hash FROM public.m2_bdj_objective_proposals
        WHERE proposal_id = :pid
    """), {'pid': str(row['proposal_id'])}).scalar_one()
    return value


def admission_state(engine, proposal_id, *, source_fingerprint, actor_id) -> dict:
    """Compose the admission state without ever inventing an authorisation.

    Order matters: approval is checked before the admission record, because an
    admission for a proposal that is not approved is meaningless rather than
    merely late.
    """
    if actor_id is None:
        raise WorkflowHeld('PROPOSAL_OWNER_REQUIRED')
    with engine.begin() as conn:
        _bind_actor(conn, actor_id)
        row = _load_proposal(conn, proposal_id)
        if row is None:
            return _state('NOT_ADMISSIBLE', 'PROPOSAL_NOT_FOUND')
        if row['source_fingerprint'] != source_fingerprint:
            return _state('NOT_ADMISSIBLE', 'PROPOSAL_SOURCE_STALE')
        if row['decision'] != 'APPROVED':
            return _state('NOT_ADMISSIBLE', 'PROPOSAL_NOT_APPROVED')

        record = conn.execute(text("""
            SELECT admission_id, decision, proposal_hash, created_at
            FROM public.m2_bdj_objective_admissions
            WHERE proposal_id = :pid
        """), {'pid': str(proposal_id)}).mappings().one_or_none()
        if record is None:
            return {**_state('HELD', 'M2_UNCERTAINTY_LINK_REQUIRED'),
                    'pending_requirement': (
                        'The owner has approved this objective but has not '
                        'recorded that the cited gap is worth researching. '
                        'An admission decision is required before an '
                        'uncertainty link can be created.')}

        # A stored hash that no longer matches means the proposal changed under
        # the admission. Treat it as stale rather than trusting the decision.
        if record['proposal_hash'] != proposal_hash(row):
            return _state('NOT_ADMISSIBLE', 'ADMISSION_PROPOSAL_CHANGED')

        return {**_state('ADMITTED', 'ADMISSION_RECORDED'),
                'admission_id': str(record['admission_id']),
                'admitted_at': record['created_at'],
                'proposal_hash': record['proposal_hash']}


def _state(state: str, reason: str) -> dict:
    """Every state carries the same authority block: all false, always."""
    return {
        'admission_state': state,
        'admission_reason': reason,
        'pending_requirement': None,
        'uncertainty_link': None,
        'qj_execution': False,
        'qg_execution': False,
        'fielding_authorized': False,
    }
