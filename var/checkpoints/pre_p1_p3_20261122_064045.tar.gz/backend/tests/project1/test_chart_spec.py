"""Contract tests for ``chart-spec/1`` and the synthetic EE-01 adapter.

These tests assert refusals and withheld states, not just happy paths: the
governance requirement is that a chart cannot invent a percentage, cannot chart
a production snapshot, and cannot present a stale or mismatched readback.
"""
from __future__ import annotations

import json
from decimal import Decimal

import pytest
from pydantic import ValidationError

from chart_fixtures import Q05_COUNTS, load_question, readback, snapshot, utc
from sitewise.domain.customer_questionnaire import digest as ee01_digest
from sitewise.project1.chart_spec import (
    ChartAdmission,
    ChartOption,
    ChartRefused,
    ChartSpec,
    MeasurementCounts,
    from_ee01,
    highest_codes,
    percent_of,
)


def build(**kwargs) -> ChartSpec:
    snap = kwargs.pop('snap', None) or snapshot(**kwargs.pop('snapshot_kwargs', {}))
    rb = kwargs.pop('rb', None) or readback(snap)
    question = kwargs.pop('question', None) or load_question()
    return from_ee01(snap, rb, question, title='Stated first-three-month interest', **kwargs)


def admitted_spec(**overrides) -> ChartSpec:
    """A contract-conformance spec with an ADMITTED admission.

    No adopted adapter can produce this in V1; it exists so the renderer path
    that *would* show an authorized percentage is exercised without any code
    path claiming authority it does not have.
    """
    V = 50
    options = [
        ChartOption(code=code, label=None, label_source='CODE_FALLBACK',
                    count=count, percentage=percent_of(count, V),
                    percentage_status='ESTIMABLE')
        for code, count in Q05_COUNTS.items()
    ]
    payload = dict(
        schema_version='chart-spec/1',
        chart_id='chart:conformance:1',
        chart_type='HORIZONTAL_BAR',
        source_provenance='TEST_FIXTURE_CONTRACT_CONFORMANCE',
        evidence_context_hash='0' * 64,
        campaign_id='campaign-0001',
        question_id='Q05',
        construct_id='D01_CONCEPT_INTENT',
        report_sections=['R03'],
        question_version='q05-v1',
        option_bank_version='bank-v1',
        stimulus_hash='stimulus-0001',
        concept_version='concept-v1',
        cohort_scope='TEST_CONFORMANCE_ONLY',
        cutoff=utc(),
        measurement=MeasurementCounts(I='UNKNOWN_NOT_ENUMERABLE', Q=55, S=53, A=50, V=V),
        denominator_scope='V = substantive answers',
        limitation='Contract-conformance fixture; not a measurement.',
        title='Stated first-three-month interest',
        question_text='Fixture question.',
        response_kind='ORDINAL',
        options=options,
        derived_lines=[],
        highest_options=highest_codes(options, V),
        limitations=['Contract-conformance fixture; not a measurement.'],
        render_state='RENDERABLE',
        admission=ChartAdmission(status='ADMITTED', authority='TEST_FIXTURE_CONTRACT_CONFORMANCE',
                                 gates=[], real_reportable=False),
    )
    payload.update(overrides)
    return ChartSpec(**payload)


# ---------------------------------------------------------------------------
# Mapping and withheld presentation
# ---------------------------------------------------------------------------

def test_synthetic_snapshot_maps_without_claiming_authority():
    spec = build()
    assert spec.render_state == 'WITHHELD_NOT_AUTHORIZED'
    assert spec.admission.status == 'HELD'
    assert spec.admission.authority == 'AUTHORITY_UNVERIFIED'
    assert spec.admission.real_reportable is False
    assert 'REPORT_ADMISSION_REQUIRED' in spec.admission.gates
    assert 'SYNTHETIC_DATA_NOT_REPORTABLE' in spec.admission.gates


def test_no_percentage_is_emitted_while_admission_is_held():
    spec = build()
    assert all(option.percentage is None for option in spec.options)
    assert all(option.percentage_status == 'WITHHELD_NOT_AUTHORIZED' for option in spec.options)
    assert all(line.percentage is None for line in spec.derived_lines)
    assert '"percentage": "33' not in json.dumps(spec.to_json())


def test_v_zero_is_not_estimable_and_never_zero_percent():
    spec = build(snapshot_kwargs={'counts': {}, 'v': 0, 's': 5, 'status': 'NOT_ESTIMABLE'})
    assert spec.measurement.V == 0
    assert spec.render_state == 'NOT_ESTIMABLE'
    assert spec.highest_options == []
    assert all(option.percentage is None for option in spec.options)
    assert all(option.percentage_status == 'NOT_ESTIMABLE' for option in spec.options)


def test_not_shown_when_no_unit_was_displayed():
    spec = build(snapshot_kwargs={'counts': {}, 'v': 0, 's': 0, 'status': 'NOT_SHOWN'})
    assert spec.render_state == 'NOT_SHOWN'
    assert spec.highest_options == []


def test_options_follow_contract_display_order_not_alphabetical():
    spec = build()
    assert [option.code for option in spec.options] == [
        'DEF_NO', 'PROB_NO', 'UNSURE', 'PROB_YES', 'DEF_YES']


def test_ordinal_values_come_from_declared_meaning_not_display_position():
    spec = build()
    assert {option.code: option.ordinal_value for option in spec.options} == {
        'DEF_NO': 1, 'PROB_NO': 2, 'UNSURE': 3, 'PROB_YES': 4, 'DEF_YES': 5}
    assert spec.response_kind == 'ORDINAL'


def test_derived_aggregate_is_not_presented_as_an_option():
    spec = build()
    codes = {option.code for option in spec.options}
    assert 'TOP_TWO_STATED_INTEREST' not in codes
    assert [line.code for line in spec.derived_lines] == ['TOP_TWO_STATED_INTEREST']
    line = spec.derived_lines[0]
    assert line.count == Q05_COUNTS['PROB_YES'] + Q05_COUNTS['DEF_YES'] == 22
    assert line.numerator_codes == ['DEF_YES', 'PROB_YES']
    assert line.output_label


def test_derived_aggregate_never_becomes_the_highest_option():
    # PROB_YES (14) is the top option; the derived 22 must not appear.
    assert build().highest_options == ['PROB_YES']


def test_tied_highest_options_are_reported_as_a_tie():
    spec = build(snapshot_kwargs={'counts': {'DEF_NO': 10, 'PROB_NO': 10,
                                             'UNSURE': 0, 'PROB_YES': 0, 'DEF_YES': 0},
                                  'v': 20, 's': 22})
    assert spec.highest_options == ['DEF_NO', 'PROB_NO']


def test_limitations_are_mandatory_and_multi_source():
    spec = build()
    assert len(spec.limitations) >= 2
    assert any('compounds a time horizon' in text for text in spec.limitations)
    assert any('Calibrated probability' in text for text in spec.limitations)


# ---------------------------------------------------------------------------
# Refusals
# ---------------------------------------------------------------------------

def test_missing_denominator_on_a_cell_is_refused():
    with pytest.raises(ChartRefused) as err:
        build(snapshot_kwargs={'cell_v': 49})
    assert err.value.code == 'CHART_CELL_DENOMINATOR_MISMATCH'


def test_stale_readback_is_refused():
    snap = snapshot()
    rb = readback(snap)
    rb['context'] = {**rb['context'], 'fingerprint': 'fp-other'}
    from sitewise.domain.customer_questionnaire import digest as ee01_digest
    rb['context_hash'] = ee01_digest(rb['context'])
    with pytest.raises(ChartRefused) as err:
        from_ee01(snap, rb, load_question(), title='t')
    assert err.value.code == 'CHART_READBACK_FINGERPRINT_MISMATCH'


def test_readback_for_a_different_snapshot_is_refused():
    snap = snapshot()
    rb = readback(snap)
    rb['context'] = {**rb['context'], 'snapshot_id': 'snap-9999'}
    from sitewise.domain.customer_questionnaire import digest as ee01_digest
    rb['context_hash'] = ee01_digest(rb['context'])
    with pytest.raises(ChartRefused) as err:
        from_ee01(snap, rb, load_question(), title='t')
    assert err.value.code == 'CHART_READBACK_STALE_SNAPSHOT'


def test_tampered_readback_context_is_refused():
    snap = snapshot()
    rb = readback(snap)
    rb['context'] = {**rb['context'], 'authority': 'AUTHORITY_GRANTED'}
    with pytest.raises(ChartRefused) as err:
        from_ee01(snap, rb, load_question(), title='t')
    assert err.value.code == 'CHART_READBACK_INTEGRITY_INVALID'


def test_version_mismatch_is_refused():
    snap = snapshot()
    snap['contract_version'] = 'ee01-diagnostic/2'
    with pytest.raises(ChartRefused) as err:
        from_ee01(snap, readback(snap), load_question(), title='t')
    assert err.value.code == 'CHART_SNAPSHOT_VERSION_MISMATCH'


def test_production_snapshot_is_refused():
    snap = snapshot(scope='PRODUCTION', origin='CUSTOMER_FIELD')
    with pytest.raises(ChartRefused) as err:
        from_ee01(snap, readback(snap), load_question(), title='t')
    assert err.value.code == 'CHART_MEASUREMENT_AUTHORITY_UNVERIFIED'
    assert err.value.status == 503


def test_synthetic_origin_marker_is_required():
    snap = snapshot()
    snap['metadata_json'] = {**snap['metadata_json'], 'origin': 'CUSTOMER_FIELD'}
    with pytest.raises(ChartRefused) as err:
        from_ee01(snap, readback(snap), load_question(), title='t')
    assert err.value.code == 'CHART_SYNTHETIC_ORIGIN_MISSING'


def test_unknown_cell_code_is_refused():
    snap = snapshot()
    snap['cells'] = [*snap['cells'], {'code': 'NOT_A_CODE', 'x': 1, 'v': 50,
                                      'percentage': None,
                                      'diagnostic_percentage': None,
                                      'status': 'WITHHELD_NOT_AUTHORIZED'}]
    with pytest.raises(ChartRefused) as err:
        from_ee01(snap, readback(snap), load_question(), title='t')
    assert err.value.code == 'CHART_UNKNOWN_CELL_CODE'


# ---------------------------------------------------------------------------
# Model invariants
# ---------------------------------------------------------------------------

def test_non_canonical_report_section_is_rejected():
    with pytest.raises(ValidationError, match='E_NONCANONICAL_REPORT_SECTION'):
        admitted_spec(report_sections=['R08_LIMITED_CONTEXT'])


def test_single_select_sum_must_equal_v():
    with pytest.raises(ValidationError, match='E_SINGLE_SELECT_SUM_MISMATCH'):
        admitted_spec(response_kind='SINGLE_SELECT', measurement=MeasurementCounts(
            I='UNKNOWN_NOT_ENUMERABLE', Q=55, S=53, A=51, V=51))


def test_option_count_above_v_is_rejected():
    options = [ChartOption(code='A', label=None, label_source='CODE_FALLBACK',
                           count=60, percentage=None,
                           percentage_status='WITHHELD_NOT_AUTHORIZED')]
    with pytest.raises(ValidationError, match='E_OPTION_COUNT_EXCEEDS_V'):
        admitted_spec(options=options, derived_lines=[], highest_options=[],
                      render_state='WITHHELD_NOT_AUTHORIZED',
                      admission=ChartAdmission(status='HELD', authority='AUTHORITY_UNVERIFIED',
                                               gates=['REPORT_ADMISSION_REQUIRED'],
                                               real_reportable=False))


def test_funnel_must_be_monotonic():
    with pytest.raises(ValidationError, match='E_FUNNEL_NON_MONOTONIC'):
        MeasurementCounts(I='UNKNOWN_NOT_ENUMERABLE', Q=10, S=11, A=10, V=10)


def test_renderable_spec_requires_a_percentage_on_every_option():
    with pytest.raises(ValidationError, match='E_RENDERABLE_OPTION_NOT_ESTIMABLE'):
        options = [ChartOption(code='A', label=None, label_source='CODE_FALLBACK',
                               count=50, percentage=None,
                               percentage_status='WITHHELD_NOT_AUTHORIZED')]
        admitted_spec(options=options, highest_options=['A'])


def test_renderable_spec_rejects_a_mismatched_percentage():
    options = [ChartOption(code='A', label=None, label_source='CODE_FALLBACK',
                           count=50, percentage=Decimal('99.0000'),
                           percentage_status='ESTIMABLE')]
    with pytest.raises(ValidationError, match='E_PERCENTAGE_MISMATCH'):
        admitted_spec(options=options, highest_options=['A'])


def test_held_spec_cannot_carry_a_percentage():
    with pytest.raises(ValidationError, match='E_PERCENTAGE_EMITTED_WITHOUT_AUTHORITY'):
        ChartOption(code='A', label=None, label_source='CODE_FALLBACK', count=5,
                    percentage=Decimal('10.0000'), percentage_status='WITHHELD_NOT_AUTHORIZED')


def test_held_admission_requires_a_gate():
    with pytest.raises(ValidationError, match='E_HELD_WITHOUT_GATE'):
        ChartAdmission(status='HELD', authority='AUTHORITY_UNVERIFIED', gates=[],
                       real_reportable=False)


def test_admitted_render_state_must_match_admission():
    with pytest.raises(ValidationError, match='E_RENDER_STATE_INCONSISTENT'):
        admitted_spec(admission=ChartAdmission(status='HELD', authority='AUTHORITY_UNVERIFIED',
                                               gates=['REPORT_ADMISSION_REQUIRED'],
                                               real_reportable=False))


def test_naive_cutoff_is_rejected():
    from datetime import datetime
    with pytest.raises(ValidationError, match='E_CUTOFF_NAIVE'):
        admitted_spec(cutoff=datetime(2026, 11, 22, 9, 0))


# ---------------------------------------------------------------------------
# Numeric policy and reproducibility
# ---------------------------------------------------------------------------

def test_percentages_are_decimal_strings_in_json_not_floats():
    spec = admitted_spec()
    payload = spec.to_json()
    for option in payload['options']:
        assert isinstance(option['percentage'], str), 'percentage must serialize as a decimal string'
    assert json.loads(json.dumps(payload))['options'][0]['percentage'] == '24.0000'


def test_no_evidential_quantity_is_a_float():
    spec = admitted_spec()
    payload = spec.to_json()
    assert isinstance(payload['measurement']['V'], int)
    assert not isinstance(payload['measurement']['V'], bool)
    assert all(isinstance(option['count'], int) for option in payload['options'])
    assert not any(isinstance(option['percentage'], float) for option in payload['options'])


def test_percentage_quantization_is_four_places_half_up():
    assert percent_of(1, 3) == Decimal('33.3333')
    assert percent_of(2, 3) == Decimal('66.6667')
    assert percent_of(50, 50) == Decimal('100.0000')
    assert percent_of(0, 50) == Decimal('0.0000')
    assert percent_of(5, 0) is None


def test_content_hash_is_deterministic_and_change_sensitive():
    first, second = build(), build()
    assert first.content_hash() == second.content_hash()
    changed = build(snapshot_kwargs={'counts': {**Q05_COUNTS, 'DEF_YES': 9}})
    assert changed.content_hash() != first.content_hash()


def test_chart_id_binds_snapshot_and_section():
    spec = build()
    assert spec.chart_id == 'chart:snap-0001:R03'


def test_chart_is_bound_to_the_same_evidence_context_as_the_explanation():
    """The explanation service refuses a mismatched ``context_hash``, so the
    chart must name the readback context it was built from — that equality is
    what makes "this explanation is about this chart" a check, not a claim."""
    snap = snapshot()
    rb = readback(snap)
    spec = from_ee01(snap, rb, load_question(), title='t')
    assert spec.evidence_context_hash == rb['context_hash']
    assert spec.evidence_context_hash == ee01_digest(rb['context'])


def test_serialized_spec_carries_all_twenty_measurement_line_fields():
    payload = build().to_json()
    required = {'source_provenance', 'campaign_id', 'question_id', 'construct_id',
                'report_sections', 'question_version', 'option_bank_version',
                'stimulus_hash', 'concept_version', 'cohort_scope', 'cutoff',
                'denominator_scope', 'limitation'}
    assert required <= set(payload)
    assert {'I', 'Q', 'S', 'A', 'V'} <= set(payload['measurement'])
    assert {'count'} <= set(payload['options'][0])
